# CubiertasChueca — Calculadora de Presupuestos Online

Herramienta de presupuesto online para CubiertasChueca, empresa especializada
en cubiertas, tejados e impermeabilizaciones en Madrid con más de 50 años de experiencia.

## Funcionalidades
- Wizard de 3 pasos con validación en tiempo real
- Cálculo con factor de pendiente real (fórmula trigonométrica coseno)
- Factor de desperdicio por material (pizarra +20%, zinc +12%...)
- Descarga de presupuesto en PDF con identidad corporativa de CubiertasChueca
- Exportación a CSV compatible con Excel
- Historial de presupuestos guardado en el navegador

## Stack
HTML5 · CSS3 · JavaScript ES6 · jsPDF · localStorage API

## Instalación
Abrir index.html con Live Server (VS Code). No requiere servidor ni instalación.
