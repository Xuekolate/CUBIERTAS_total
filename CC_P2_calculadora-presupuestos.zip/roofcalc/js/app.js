/* ============================================================
   app.js — Calculadora de Presupuestos CubiertasChueca
   ============================================================
   Herramienta de presupuesto online para CubiertasChueca,
   empresa especializada en cubiertas y tejados en Madrid
   con más de 50 años de experiencia.

   Hace 4 cosas:
     1. Gestiona el wizard de 3 pasos
     2. Calcula el presupuesto en tiempo real usando las
        fórmulas reales del sector (factor de pendiente con coseno,
        factor de desperdicio por material)
     3. Genera el PDF y el CSV para descargar
     4. Guarda el historial de presupuestos en localStorage
   ============================================================ */

'use strict';

document.addEventListener('DOMContentLoaded', function () {

  // ============================================================
  // CATÁLOGO DE MATERIALES DE CUBIERTASCHUECA
  // Precios en €/m² instalado (material + mano de obra)
  // Fuente: tarifas reales del sector en Madrid (2024-2025)
  // ============================================================
  const MATERIALES = {
    pizarra: {
      nombre:            'Pizarra natural española',
      precio:            55,
      factorDesperdicio: 1.20,
      // La pizarra requiere un 20% extra de material por los cortes
      // en bordes, limatesas y canaletas del tejado.
      garantia:          '+100 años de durabilidad',
      origen:            'Galicia y Castilla y León'
    },
    zinc: {
      nombre:            'Zinc titanio pre-patinado',
      precio:            82,
      factorDesperdicio: 1.12,
      garantia:          '80-100 años de vida útil',
      origen:            'Formato standing seam, 0,7mm'
    },
    teja: {
      nombre:            'Teja cerámica',
      precio:            48,
      factorDesperdicio: 1.15,
      garantia:          '50-75 años de durabilidad',
      origen:            'Producción nacional'
    },
    cobre: {
      nombre:            'Cobre',
      precio:            96,
      factorDesperdicio: 1.12,
      garantia:          '100+ años de vida útil',
      origen:            'Acabado premium'
    },
    imperm: {
      nombre:            'Impermeabilización con poliurea',
      precio:            32,
      factorDesperdicio: 1.05,
      // La poliurea es una membrana continua sin juntas,
      // apenas hay desperdicio (solo un 5% por bordes y sumideros)
      garantia:          '25 años — garantía en obra',
      origen:            'Aplicación en frío, membrana continua'
    }
  };

  // Trabajos adicionales que CubiertasChueca ofrece
  const EXTRAS = {
    canalon:     { nombre: 'Instalación de canalones nuevos',   precio: 480  },
    lucernario:  { nombre: 'Lucernario / claraboya',            precio: 1200 },
    aislamiento: { nombre: 'Aislamiento térmico bajo cubierta', precio: 680  },
    andamio:     { nombre: 'Montaje y desmontaje de andamio',   precio: 950  }
  };

  const IVA = 0.21; // 21% de IVA vigente en España para obras de construcción

  // Nombre de la empresa para los documentos generados
  const EMPRESA = {
    nombre:    'CubiertasChueca',
    eslogan:   'Más de 50 años haciendo cubiertas en Madrid',
    direccion: 'C/ Sorbesopas Nº 20, Alcorcón 28921',
    telefono:  '600 000 000',
    email:     'info@cubiertaschueca.es',
    web:       'www.cubiertaschueca.es'
  };

  // ============================================================
  // ESTADO CENTRALIZADO
  // Guardamos todos los datos del presupuesto en curso aquí
  // para no tener que leer el DOM en el paso 3
  // ============================================================
  let estado = {
    paso:          1,
    cliente:       {},
    obra:          {},
    calculo:       {},
    idPresupuesto: null
  };

  // ============================================================
  // REFERENCIAS AL DOM
  // ============================================================
  const pasos   = document.querySelectorAll('.paso');
  const stepNav = document.querySelectorAll('.step');

  // Paso 1 — datos del cliente
  const inNombre    = document.getElementById('cli-nombre');
  const inEmpresa   = document.getElementById('cli-empresa');
  const inEmail     = document.getElementById('cli-email');
  const inTelefono  = document.getElementById('cli-telefono');
  const inDireccion = document.getElementById('cli-direccion');

  // Paso 2 — configuración de la obra
  const selTipo     = document.getElementById('obra-tipo');
  const inLargo     = document.getElementById('obra-largo');
  const inAncho     = document.getElementById('obra-ancho');
  const inPendiente = document.getElementById('obra-pendiente');
  const outPend     = document.getElementById('out-pendiente');
  const chkExtras   = document.querySelectorAll('.extra-check');

  // Panel de cálculo en tiempo real (paso 2)
  const resBruto       = document.getElementById('res-bruto');
  const resFactor      = document.getElementById('res-factor');
  const resNeto        = document.getElementById('res-neto');
  const resDesperdicio = document.getElementById('res-desperdicio');
  const resMaterial    = document.getElementById('res-material');
  const resTotal       = document.getElementById('res-total');

  // Historial
  const historialVacio = document.getElementById('historial-vacio');
  const historialLista = document.getElementById('historial-lista');

  // Año en el footer
  const footerYear = document.getElementById('footer-year');
  if (footerYear) footerYear.textContent = new Date().getFullYear();

  // ============================================================
  // NAVEGACIÓN ENTRE PASOS DEL WIZARD
  // ============================================================
  function mostrarPaso(num) {
    pasos.forEach(function (p) { p.classList.add('oculto'); });
    document.getElementById('paso-' + num).classList.remove('oculto');

    stepNav.forEach(function (s) { s.classList.remove('activo', 'completado'); });
    for (var i = 1; i < num; i++) {
      document.querySelector('.step[data-step="' + i + '"]').classList.add('completado');
    }
    document.querySelector('.step[data-step="' + num + '"]').classList.add('activo');

    estado.paso = num;
    window.scrollTo(0, 0);
  }

  // ============================================================
  // FÓRMULA DEL FACTOR DE PENDIENTE
  // ============================================================
  /* Fórmula trigonométrica real que usan los técnicos de cubiertas:
     Un tejado con 30° de inclinación tiene más metros de cubierta
     real que su proyección horizontal (lo que ves desde arriba).

     Factor = 1 / cos(ángulo_en_radianes)

     Ejemplo real de CubiertasChueca:
       Casa con planta 10×8m = 80 m² de planta
       Con 30° → 80 / cos(30°) = 80 / 0.866 = 92.4 m² reales */
  function calcularFactorPendiente(grados) {
    if (grados === 0) return 1.00; // Cubierta plana — sin corrección
    var radianes = grados * (Math.PI / 180);
    return 1 / Math.cos(radianes);
  }

  // ============================================================
  // CÁLCULO EN TIEMPO REAL
  // Se llama cada vez que el usuario cambia cualquier campo del paso 2
  // ============================================================
  function recalcular() {
    var largo     = parseFloat(inLargo.value)   || 0;
    var ancho     = parseFloat(inAncho.value)   || 0;
    var pendiente = parseInt(inPendiente.value) || 0;
    var tipoKey   = selTipo.value;
    var mat       = MATERIALES[tipoKey];

    var m2Brutos    = largo * ancho;
    var factor      = calcularFactorPendiente(pendiente);
    var m2Netos     = m2Brutos * factor;
    var desperdicio = mat ? mat.factorDesperdicio : 1;
    var m2Material  = m2Netos * desperdicio;
    var costeMat    = mat ? m2Material * mat.precio : 0;

    var totalExtras = 0;
    chkExtras.forEach(function (chk) {
      if (chk.checked && EXTRAS[chk.value]) {
        totalExtras += EXTRAS[chk.value].precio;
      }
    });

    var subtotal    = costeMat + totalExtras;
    var totalConIva = subtotal * (1 + IVA);

    resBruto.textContent       = m2Brutos.toFixed(1)  + ' m²';
    resFactor.textContent      = '×' + factor.toFixed(2);
    resNeto.textContent        = m2Netos.toFixed(1)   + ' m²';
    resDesperdicio.textContent = mat
      ? '×' + desperdicio.toFixed(2) + ' (' + mat.nombre + ')'
      : '—';
    resMaterial.textContent    = m2Material.toFixed(1) + ' m²';
    resTotal.textContent       = totalConIva > 0
      ? totalConIva.toLocaleString('es-ES', { maximumFractionDigits: 0 }) + ' €'
      : '0 €';

    estado.calculo = {
      m2Brutos, factor, m2Netos, m2Material, desperdicio,
      costeMat, totalExtras,
      subtotal,
      iva:         subtotal * IVA,
      total:       totalConIva
    };
  }

  selTipo.addEventListener('change', recalcular);
  inLargo.addEventListener('input',  recalcular);
  inAncho.addEventListener('input',  recalcular);
  inPendiente.addEventListener('input', function () {
    outPend.textContent = this.value + '°';
    recalcular();
  });
  chkExtras.forEach(function (chk) {
    chk.addEventListener('change', recalcular);
  });
  recalcular(); // Cálculo inicial

  // ============================================================
  // VALIDACIONES
  // ============================================================
  function mostrarError(campo, idMensaje, hayError) {
    var msg = document.getElementById(idMensaje);
    if (hayError) {
      campo.classList.add('error');
      if (msg) msg.classList.add('visible');
    } else {
      campo.classList.remove('error');
      if (msg) msg.classList.remove('visible');
    }
  }

  function validarPaso1() {
    var nombreOk   = inNombre.value.trim().length >= 2;
    var emailOk    = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(inEmail.value.trim());
    var telOk      = /^[0-9]{9}$/.test(inTelefono.value.trim());
    var dirOk      = inDireccion.value.trim().length >= 5;

    mostrarError(inNombre,    'err-cli-nombre',    !nombreOk);
    mostrarError(inEmail,     'err-cli-email',     !emailOk);
    mostrarError(inTelefono,  'err-cli-telefono',  !telOk);
    mostrarError(inDireccion, 'err-cli-direccion', !dirOk);

    if (nombreOk && emailOk && telOk && dirOk) {
      estado.cliente = {
        nombre:    inNombre.value.trim(),
        empresa:   inEmpresa.value.trim(),
        email:     inEmail.value.trim(),
        telefono:  inTelefono.value.trim(),
        direccion: inDireccion.value.trim()
      };
      return true;
    }
    return false;
  }

  function validarPaso2() {
    var tipoOk  = selTipo.value !== '';
    var largoOk = parseFloat(inLargo.value) > 0;
    var anchoOk = parseFloat(inAncho.value) > 0;

    mostrarError(selTipo, 'err-obra-tipo',  !tipoOk);
    mostrarError(inLargo, 'err-obra-largo', !largoOk);
    mostrarError(inAncho, 'err-obra-ancho', !anchoOk);

    if (tipoOk && largoOk && anchoOk) {
      var extrasSeleccionados = [];
      chkExtras.forEach(function (chk) {
        if (chk.checked) extrasSeleccionados.push(chk.value);
      });
      estado.obra = {
        tipo:      selTipo.value,
        largo:     parseFloat(inLargo.value),
        ancho:     parseFloat(inAncho.value),
        pendiente: parseInt(inPendiente.value),
        extras:    extrasSeleccionados
      };
      return true;
    }
    return false;
  }

  // ============================================================
  // BOTONES DE NAVEGACIÓN
  // ============================================================
  document.getElementById('btn-paso1-sig').addEventListener('click', function () {
    if (validarPaso1()) mostrarPaso(2);
  });
  document.getElementById('btn-paso2-ant').addEventListener('click', function () {
    mostrarPaso(1);
  });
  document.getElementById('btn-paso2-sig').addEventListener('click', function () {
    if (validarPaso2()) { generarResumen(); mostrarPaso(3); }
  });
  document.getElementById('btn-paso3-ant').addEventListener('click', function () {
    mostrarPaso(2);
  });
  document.getElementById('btn-nuevo').addEventListener('click', function () {
    resetearApp(); mostrarPaso(1);
  });

  // ============================================================
  // GENERAR RESUMEN EN EL PASO 3
  // ============================================================
  function generarResumen() {
    var mat      = MATERIALES[estado.obra.tipo];
    var calc     = estado.calculo;
    var cli      = estado.cliente;
    var fechaHoy = new Date().toLocaleDateString('es-ES');
    var validez  = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000)
                     .toLocaleDateString('es-ES');

    estado.idPresupuesto = 'CC-' + Date.now();
    // CC = CubiertasChueca — prefijo de la empresa en todas las referencias

    var extrasHtml = estado.obra.extras.map(function (key) {
      return '<tr>' +
        '<td>' + EXTRAS[key].nombre + '</td>' +
        '<td></td>' +
        '<td>' + EXTRAS[key].precio.toLocaleString('es-ES') + ' €</td>' +
      '</tr>';
    }).join('');

    document.getElementById('presupuesto-final').innerHTML =
      '<header class="presupuesto-header">' +
        '<div class="presupuesto-empresa">' +
          '<span class="presupuesto-logo">🏠 CubiertasChueca</span>' +
          '<span class="presupuesto-eslogan">' + EMPRESA.eslogan + '</span>' +
        '</div>' +
        '<div class="presupuesto-meta">' +
          '<p><strong>Ref:</strong> ' + estado.idPresupuesto + '</p>' +
          '<p><strong>Fecha:</strong> ' + fechaHoy + '</p>' +
          '<p><strong>Válido hasta:</strong> ' + validez + '</p>' +
        '</div>' +
      '</header>' +

      '<section class="presupuesto-cliente">' +
        '<h3>Datos del cliente</h3>' +
        '<p><strong>' + cli.nombre + '</strong>' +
          (cli.empresa ? ' — ' + cli.empresa : '') + '</p>' +
        '<p>' + cli.email + ' | ' + cli.telefono + '</p>' +
        '<p>Dirección de la obra: ' + cli.direccion + '</p>' +
      '</section>' +

      '<section class="presupuesto-desglose">' +
        '<h3>Desglose del presupuesto</h3>' +
        '<table class="tabla-desglose">' +
          '<thead>' +
            '<tr>' +
              '<th>Concepto</th><th>Medición</th><th>Importe</th>' +
            '</tr>' +
          '</thead>' +
          '<tbody>' +
            '<tr>' +
              '<td>' + mat.nombre + '</td>' +
              '<td>' + calc.m2Material.toFixed(1) + ' m² × ' + mat.precio + ' €/m²</td>' +
              '<td>' + calc.costeMat.toLocaleString('es-ES', { maximumFractionDigits: 0 }) + ' €</td>' +
            '</tr>' +
            extrasHtml +
            '<tr class="subtotal-row">' +
              '<td colspan="2">Base imponible</td>' +
              '<td>' + calc.subtotal.toLocaleString('es-ES', { maximumFractionDigits: 0 }) + ' €</td>' +
            '</tr>' +
            '<tr>' +
              '<td colspan="2">IVA (21%)</td>' +
              '<td>' + calc.iva.toLocaleString('es-ES', { maximumFractionDigits: 0 }) + ' €</td>' +
            '</tr>' +
            '<tr class="total-row">' +
              '<td colspan="2"><strong>TOTAL</strong></td>' +
              '<td><strong>' + calc.total.toLocaleString('es-ES', { maximumFractionDigits: 0 }) + ' €</strong></td>' +
            '</tr>' +
          '</tbody>' +
        '</table>' +
        '<p class="nota-presupuesto">' +
          '* Presupuesto orientativo para ' + calc.m2Brutos.toFixed(1) + ' m² de planta ' +
          '(' + calc.m2Netos.toFixed(1) + ' m² reales con pendiente de ' + estado.obra.pendiente + '°). ' +
          'El precio final se confirma tras <strong>visita técnica gratuita</strong>. ' +
          'Todos los trabajos incluyen <strong>15 años de garantía</strong>. ' +
          'Presupuesto válido 30 días.' +
        '</p>' +
      '</section>' +

      '<footer class="presupuesto-footer">' +
        '<p>' + EMPRESA.nombre + ' · ' + EMPRESA.direccion + '</p>' +
        '<p>Tel: ' + EMPRESA.telefono + ' · ' + EMPRESA.email + ' · ' + EMPRESA.web + '</p>' +
      '</footer>';
  }

  // ============================================================
  // GENERAR PDF
  // ============================================================
  document.getElementById('btn-pdf').addEventListener('click', function () {
    if (!window.jspdf) {
      alert('Error al cargar el generador de PDF. Comprueba tu conexión a internet.');
      return;
    }

    var doc  = new window.jspdf.jsPDF();
    var calc = estado.calculo;
    var cli  = estado.cliente;
    var mat  = MATERIALES[estado.obra.tipo];

    // Cabecera con el nombre de la empresa en el color corporativo
    doc.setFontSize(22);
    doc.setTextColor(233, 69, 96); // #e94560 — color corporativo de CubiertasChueca
    doc.text('CubiertasChueca', 20, 22);

    doc.setFontSize(11);
    doc.setTextColor(100, 100, 100);
    doc.text(EMPRESA.eslogan, 20, 30);

    // Línea separadora en el color corporativo
    doc.setDrawColor(233, 69, 96);
    doc.setLineWidth(0.5);
    doc.line(20, 34, 190, 34);

    // Datos del presupuesto
    doc.setFontSize(10);
    doc.setTextColor(80, 80, 80);
    doc.text('Ref: ' + estado.idPresupuesto, 20, 42);
    doc.text('Fecha: ' + new Date().toLocaleDateString('es-ES'), 100, 42);

    // Datos del cliente
    doc.setFontSize(13);
    doc.setTextColor(26, 26, 46); // #1a1a2e — azul primario
    doc.text('Cliente', 20, 55);
    doc.setFontSize(11);
    doc.setTextColor(60, 60, 60);
    doc.text(cli.nombre + (cli.empresa ? ' — ' + cli.empresa : ''), 20, 63);
    doc.text(cli.email + '  |  Tel: ' + cli.telefono, 20, 70);
    doc.text('Obra en: ' + cli.direccion, 20, 77);

    // Desglose
    doc.setFontSize(13);
    doc.setTextColor(26, 26, 46);
    doc.text('Presupuesto detallado', 20, 92);

    doc.setFontSize(10);
    doc.setTextColor(60, 60, 60);
    doc.text(
      mat.nombre + ':  ' +
      calc.m2Material.toFixed(1) + ' m² × ' + mat.precio + ' €/m²  =  ' +
      calc.costeMat.toLocaleString('es-ES', { maximumFractionDigits: 0 }) + ' €',
      20, 102
    );

    var yPos = 110;
    estado.obra.extras.forEach(function (key) {
      doc.text(
        EXTRAS[key].nombre + ':  ' +
        EXTRAS[key].precio.toLocaleString('es-ES') + ' €',
        20, yPos
      );
      yPos += 8;
    });

    // Totales
    yPos += 4;
    doc.setDrawColor(200, 200, 200);
    doc.line(20, yPos, 190, yPos);
    yPos += 8;
    doc.text('Base imponible:  ' + calc.subtotal.toLocaleString('es-ES', { maximumFractionDigits: 0 }) + ' €', 20, yPos);
    yPos += 8;
    doc.text('IVA 21%:  ' + calc.iva.toLocaleString('es-ES', { maximumFractionDigits: 0 }) + ' €', 20, yPos);
    yPos += 12;

    doc.setFontSize(16);
    doc.setTextColor(233, 69, 96);
    doc.text(
      'TOTAL:  ' + calc.total.toLocaleString('es-ES', { maximumFractionDigits: 0 }) + ' €',
      20, yPos
    );

    // Nota y pie de empresa
    doc.setFontSize(9);
    doc.setTextColor(140, 140, 140);
    doc.text(
      'Presupuesto orientativo. El precio final se confirma tras visita técnica gratuita.',
      20, yPos + 14
    );
    doc.text('Todos los trabajos de CubiertasChueca incluyen 15 años de garantía.', 20, yPos + 21);

    // Pie
    doc.setDrawColor(233, 69, 96);
    doc.line(20, 270, 190, 270);
    doc.setFontSize(9);
    doc.setTextColor(100, 100, 100);
    doc.text(
      EMPRESA.nombre + '  ·  ' + EMPRESA.direccion +
      '  ·  Tel: ' + EMPRESA.telefono + '  ·  ' + EMPRESA.email,
      105, 277, { align: 'center' }
    );

    doc.save('presupuesto-cubiertaschueca-' + estado.idPresupuesto + '.pdf');
  });

  // ============================================================
  // EXPORTAR A CSV (compatible con Excel)
  // ============================================================
  document.getElementById('btn-csv').addEventListener('click', function () {
    var calc = estado.calculo;
    var cli  = estado.cliente;
    var mat  = MATERIALES[estado.obra.tipo];

    var cabecera = [
      'Empresa', 'Referencia', 'Fecha', 'Cliente', 'Empresa cliente',
      'Email', 'Teléfono', 'Dirección obra', 'Material', 'Garantía',
      'M² planta', 'Pendiente (°)', 'Factor pendiente', 'M² cubierta real',
      'M² material', 'Coste material', 'Extras', 'Base imponible', 'IVA 21%', 'TOTAL'
    ];

    var datos = [
      EMPRESA.nombre,
      estado.idPresupuesto,
      new Date().toLocaleDateString('es-ES'),
      cli.nombre,
      cli.empresa || '',
      cli.email,
      cli.telefono,
      cli.direccion,
      mat.nombre,
      mat.garantia,
      calc.m2Brutos.toFixed(1),
      estado.obra.pendiente,
      calc.factor.toFixed(3),
      calc.m2Netos.toFixed(1),
      calc.m2Material.toFixed(1),
      calc.costeMat.toFixed(0),
      calc.totalExtras.toFixed(0),
      calc.subtotal.toFixed(0),
      calc.iva.toFixed(0),
      calc.total.toFixed(0)
    ];

    function filaACSV(fila) {
      return fila.map(function (celda) {
        return '"' + String(celda).replace(/"/g, '""') + '"';
      }).join(',');
    }

    var csvTexto = filaACSV(cabecera) + '\n' + filaACSV(datos);

    // '\uFEFF' = BOM UTF-8, necesario para que Excel muestre
    // tildes y la ñ correctamente en Windows
    var blob = new Blob(['\uFEFF' + csvTexto], { type: 'text/csv;charset=utf-8;' });
    var url  = URL.createObjectURL(blob);
    var a    = document.createElement('a');
    a.href     = url;
    a.download = 'presupuesto-cubiertaschueca-' + estado.idPresupuesto + '.csv';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  });

  // ============================================================
  // GUARDAR EN HISTORIAL (localStorage)
  // ============================================================
  document.getElementById('btn-guardar').addEventListener('click', function () {
    this.disabled    = true;
    this.textContent = '✓ Guardado';

    var historial = JSON.parse(localStorage.getItem('cc_presupuestos') || '[]');
    // 'cc_presupuestos' = CubiertasChueca presupuestos — clave en localStorage

    historial.push({
      id:      estado.idPresupuesto,
      fecha:   new Date().toLocaleDateString('es-ES'),
      cliente: estado.cliente.nombre,
      tipo:    MATERIALES[estado.obra.tipo].nombre,
      total:   estado.calculo.total,
      estado:  JSON.parse(JSON.stringify(estado)) // copia profunda del estado
    });

    localStorage.setItem('cc_presupuestos', JSON.stringify(historial));
    renderHistorial();
  });

  function renderHistorial() {
    var historial = JSON.parse(localStorage.getItem('cc_presupuestos') || '[]');
    historialLista.innerHTML = '';

    if (historial.length === 0) {
      historialVacio.style.display = 'block';
      return;
    }

    historialVacio.style.display = 'none';

    historial.slice().reverse().forEach(function (p) {
      var li = document.createElement('li');
      li.classList.add('historial-item');
      li.innerHTML =
        '<span class="hist-id">'      + p.id      + '</span>' +
        '<span class="hist-fecha">'   + p.fecha   + '</span>' +
        '<span class="hist-cliente">' + p.cliente + '</span>' +
        '<span class="hist-tipo">'    + p.tipo    + '</span>' +
        '<span class="hist-total">'   +
          p.total.toLocaleString('es-ES', { maximumFractionDigits: 0 }) + ' €' +
        '</span>' +
        '<button class="btn-eliminar" data-id="' + p.id + '" ' +
                'aria-label="Eliminar presupuesto ' + p.id + '">🗑</button>';
      historialLista.appendChild(li);
    });

    historialLista.addEventListener('click', function (e) {
      var btn = e.target.closest('.btn-eliminar');
      if (!btn) return;
      eliminarDelHistorial(btn.getAttribute('data-id'));
    });
  }

  function eliminarDelHistorial(id) {
    var historial = JSON.parse(localStorage.getItem('cc_presupuestos') || '[]');
    localStorage.setItem(
      'cc_presupuestos',
      JSON.stringify(historial.filter(function (p) { return p.id !== id; }))
    );
    renderHistorial();
  }

  // ============================================================
  // RESET COMPLETO
  // ============================================================
  function resetearApp() {
    estado = { paso: 1, cliente: {}, obra: {}, calculo: {}, idPresupuesto: null };
    inNombre.value    = '';
    inEmpresa.value   = '';
    inEmail.value     = '';
    inTelefono.value  = '';
    inDireccion.value = '';
    selTipo.value     = '';
    inLargo.value     = '';
    inAncho.value     = '';
    inPendiente.value = 30;
    outPend.textContent = '30°';
    chkExtras.forEach(function (chk) { chk.checked = false; });
    document.querySelectorAll('.error').forEach(function (el) { el.classList.remove('error'); });
    document.querySelectorAll('.msg-error').forEach(function (el) { el.classList.remove('visible'); });

    var btnGuardar = document.getElementById('btn-guardar');
    if (btnGuardar) {
      btnGuardar.disabled    = false;
      btnGuardar.textContent = '💾 Guardar presupuesto';
    }
    recalcular();
  }

  // ============================================================
  // INICIO
  // ============================================================
  mostrarPaso(1);
  renderHistorial();

}); // Fin DOMContentLoaded
