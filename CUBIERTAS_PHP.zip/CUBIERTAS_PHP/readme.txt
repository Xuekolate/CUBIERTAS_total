https://github.com/Xuekolate/CUBIERTAS_PHP

las credenciales están en la carpeta config/db.php