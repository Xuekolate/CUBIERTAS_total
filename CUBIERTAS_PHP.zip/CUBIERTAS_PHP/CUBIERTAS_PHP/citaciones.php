<?php
session_start(); require_once 'config/db.php';
if (!isset($_SESSION['rol']) || $_SESSION['rol'] !== 'user') { header('Location: login.php'); exit; }
$idUser=$_SESSION['idUser']; $errores=[]; $ok=''; $hoy=date('Y-m-d');

if ($_SERVER['REQUEST_METHOD']==='POST') {
    $action=$_POST['action']??'';
    if ($action==='crear') {
        $fecha=trim($_POST['fecha_cita']??''); $motivo=trim($_POST['motivo_cita']??'');
        if (empty($fecha))     $errores[]='La fecha es obligatoria.';
        elseif ($fecha<$hoy)   $errores[]='La fecha no puede ser anterior a hoy.';
        if (empty($errores)) { $pdo->prepare("INSERT INTO citas (idUser,fecha_cita,motivo_cita) VALUES (?,?,?)")->execute([$idUser,$fecha,$motivo]); $ok='Cita creada correctamente.'; }
    }
    if ($action==='editar') {
        $idCita=(int)($_POST['idCita']??0); $fecha=trim($_POST['fecha_cita']??''); $motivo=trim($_POST['motivo_cita']??'');
        $st=$pdo->prepare("SELECT fecha_cita FROM citas WHERE idCita=? AND idUser=?"); $st->execute([$idCita,$idUser]); $cita=$st->fetch();
        if (!$cita)                       $errores[]='Cita no encontrada.';
        elseif ($cita['fecha_cita']<$hoy) $errores[]='No se puede modificar una cita pasada.';
        elseif (empty($fecha))            $errores[]='La fecha es obligatoria.';
        elseif ($fecha<$hoy)              $errores[]='La nueva fecha no puede ser anterior a hoy.';
        if (empty($errores)) { $pdo->prepare("UPDATE citas SET fecha_cita=?,motivo_cita=? WHERE idCita=? AND idUser=?")->execute([$fecha,$motivo,$idCita,$idUser]); $ok='Cita actualizada.'; }
    }
    if ($action==='eliminar') {
        $idCita=(int)($_POST['idCita']??0);
        $st=$pdo->prepare("SELECT fecha_cita FROM citas WHERE idCita=? AND idUser=?"); $st->execute([$idCita,$idUser]); $cita=$st->fetch();
        if (!$cita)                       $errores[]='Cita no encontrada.';
        elseif ($cita['fecha_cita']<$hoy) $errores[]='No se puede eliminar una cita pasada.';
        if (empty($errores)) { $pdo->prepare("DELETE FROM citas WHERE idCita=? AND idUser=?")->execute([$idCita,$idUser]); $ok='Cita eliminada.'; }
    }
}
$st=$pdo->prepare("SELECT * FROM citas WHERE idUser=? ORDER BY fecha_cita ASC"); $st->execute([$idUser]); $citas=$st->fetchAll();
$editando=null;
if (isset($_GET['editar'])) { $st=$pdo->prepare("SELECT * FROM citas WHERE idCita=? AND idUser=?"); $st->execute([(int)$_GET['editar'],$idUser]); $editando=$st->fetch(); }
?>
<!DOCTYPE html>
<html lang="es">
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Mis citas | CubiertasChueca</title>
  <link href="https://fonts.googleapis.com/css2?family=Work+Sans:wght@300;400;600&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="css/style.css">
</head>
<body>
<?php include 'includes/navbar.php'; ?>
<main>
<div class="container" style="padding-top:20px">
  <div class="admin-header-php">
    <h1>📅 Mis citas</h1>
    <button class="btn-enviar" onclick="document.getElementById('modal-nueva').classList.toggle('open')">+ Nueva cita</button>
  </div>

  <?php if ($ok): ?><div class="alert-php alert-php-success">✅ <?= htmlspecialchars($ok) ?></div><?php endif; ?>
  <?php if (!empty($errores)): ?><div class="alert-php alert-php-danger"><ul style="margin:0;padding-left:20px"><?php foreach($errores as $e): ?><li><?= htmlspecialchars($e) ?></li><?php endforeach; ?></ul></div><?php endif; ?>

  <?php if ($editando && $editando['fecha_cita']>=$hoy): ?>
  <div class="php-card">
    <h2>✏️ Editar cita</h2>
    <form method="POST" action="citaciones.php">
      <input type="hidden" name="action" value="editar">
      <input type="hidden" name="idCita" value="<?= $editando['idCita'] ?>">
      <div class="php-form-row">
        <div class="php-form-group"><label>Fecha *</label><input type="date" name="fecha_cita" value="<?= $editando['fecha_cita'] ?>" min="<?= $hoy ?>" required></div>
        <div class="php-form-group"><label>Motivo</label><input type="text" name="motivo_cita" value="<?= htmlspecialchars($editando['motivo_cita']??'') ?>"></div>
      </div>
      <div class="d-flex gap-2">
        <button type="submit" class="btn-enviar">💾 Guardar</button>
        <a href="citaciones.php" class="btn-reset" style="padding:10px 20px;text-decoration:none">Cancelar</a>
      </div>
    </form>
  </div>
  <?php endif; ?>

  <?php if (empty($citas)): ?>
    <div class="alert-php alert-php-info">No tienes citas programadas. ¡Solicita una!</div>
  <?php else: ?>
    <?php foreach ($citas as $c): $pasada=$c['fecha_cita']<$hoy; ?>
    <div class="cita-item <?= $pasada?'pasada':'' ?>">
      <div class="cita-date"><?= date('d/m',strtotime($c['fecha_cita'])) ?><br><small><?= date('Y',strtotime($c['fecha_cita'])) ?></small></div>
      <div class="cita-info">
        <h4><?= $pasada?'📋 Realizada':'🔜 Pendiente' ?></h4>
        <p><?= !empty($c['motivo_cita'])?htmlspecialchars($c['motivo_cita']):'<em>Sin motivo especificado</em>' ?></p>
      </div>
      <?php if (!$pasada): ?>
      <div class="cita-actions">
        <a href="citaciones.php?editar=<?= $c['idCita'] ?>" class="btn-php btn-php-warning btn-php-sm">✏️</a>
        <form method="POST" style="display:inline" onsubmit="return confirm('¿Eliminar esta cita?')">
          <input type="hidden" name="action" value="eliminar">
          <input type="hidden" name="idCita" value="<?= $c['idCita'] ?>">
          <button type="submit" class="btn-php btn-php-danger btn-php-sm">🗑️</button>
        </form>
      </div>
      <?php else: ?><small class="text-gray">Cita pasada</small><?php endif; ?>
    </div>
    <?php endforeach; ?>
  <?php endif; ?>
</div>
</main>

<div class="modal-overlay-php" id="modal-nueva">
  <div class="modal-php">
    <h3>📅 Nueva cita</h3>
    <form method="POST" action="citaciones.php">
      <input type="hidden" name="action" value="crear">
      <div class="php-form-group"><label>Fecha *</label><input type="date" name="fecha_cita" min="<?= $hoy ?>" required></div>
      <div class="php-form-group"><label>Motivo <small class="text-gray">(opcional)</small></label>
        <textarea name="motivo_cita" rows="3" placeholder="Describe el motivo de la cita..."></textarea></div>
      <div class="d-flex gap-2">
        <button type="submit" class="btn-enviar">Solicitar cita</button>
        <button type="button" class="btn-reset" onclick="document.getElementById('modal-nueva').classList.remove('open')">Cancelar</button>
      </div>
    </form>
  </div>
</div>

<footer><div class="footer-aviso"><p>&copy; <span id="footer-year"></span> CubiertasChueca.</p></div></footer>
<script src="js/main.js"></script>
</body></html>
