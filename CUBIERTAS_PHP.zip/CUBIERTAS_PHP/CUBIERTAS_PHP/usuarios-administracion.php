<?php
session_start(); require_once 'config/db.php';
if (!isset($_SESSION['rol']) || $_SESSION['rol'] !== 'admin') { header('Location: index.php'); exit; }
$errores=[]; $ok='';

if ($_SERVER['REQUEST_METHOD']==='POST') {
    $action=$_POST['action']??'';
    if ($action==='crear') {
        $n=trim($_POST['nombre']??''); $ap=trim($_POST['apellidos']??''); $em=trim($_POST['email']??'');
        $tel=trim($_POST['telefono']??''); $fn=trim($_POST['fecha_nacimiento']??'');
        $dir=trim($_POST['direccion']??''); $sx=trim($_POST['sexo']??'');
        $usr=trim($_POST['usuario']??''); $pw=$_POST['password']??'';
        $rol=in_array($_POST['rol']??'',['admin','user'])?$_POST['rol']:'user';
        if(empty($n))   $errores[]='Nombre obligatorio.';
        if(empty($ap))  $errores[]='Apellidos obligatorios.';
        if(!filter_var($em,FILTER_VALIDATE_EMAIL)) $errores[]='Email no válido.';
        if(empty($tel)) $errores[]='Teléfono obligatorio.';
        if(empty($fn))  $errores[]='Fecha nacimiento obligatoria.';
        if(empty($sx))  $errores[]='Sexo obligatorio.';
        if(empty($usr)) $errores[]='Usuario obligatorio.';
        if(strlen($pw)<6) $errores[]='Contraseña mínimo 6 caracteres.';
        if(empty($errores)){
            $st=$pdo->prepare("SELECT idUser FROM users_data WHERE email=?"); $st->execute([$em]);
            if($st->fetch()) $errores[]='Email ya registrado.';
            $st=$pdo->prepare("SELECT idLogin FROM users_login WHERE usuario=?"); $st->execute([$usr]);
            if($st->fetch()) $errores[]='Usuario ya en uso.';
        }
        if(empty($errores)){
            $pdo->beginTransaction();
            $pdo->prepare("INSERT INTO users_data (nombre,apellidos,email,telefono,fecha_nacimiento,direccion,sexo) VALUES (?,?,?,?,?,?,?)")->execute([$n,$ap,$em,$tel,$fn,$dir,$sx]);
            $id=$pdo->lastInsertId();
            $pdo->prepare("INSERT INTO users_login (idUser,usuario,password,rol) VALUES (?,?,?,?)")->execute([$id,$usr,password_hash($pw,PASSWORD_DEFAULT),$rol]);
            $pdo->commit(); $ok='Usuario creado correctamente.';
        }
    }
    if ($action==='actualizar') {
        $idE=(int)($_POST['idUser']??0); $n=trim($_POST['nombre']??''); $ap=trim($_POST['apellidos']??'');
        $em=trim($_POST['email']??''); $tel=trim($_POST['telefono']??''); $fn=trim($_POST['fecha_nacimiento']??'');
        $dir=trim($_POST['direccion']??''); $sx=trim($_POST['sexo']??'');
        $rol=in_array($_POST['rol']??'',['admin','user'])?$_POST['rol']:'user'; $np=$_POST['password_nueva']??'';
        if(empty($n))  $errores[]='Nombre obligatorio.'; if(empty($ap)) $errores[]='Apellidos obligatorios.';
        if(!filter_var($em,FILTER_VALIDATE_EMAIL)) $errores[]='Email no válido.';
        if(empty($tel)) $errores[]='Teléfono obligatorio.'; if(empty($fn)) $errores[]='Fecha nacimiento obligatoria.';
        if(empty($sx)) $errores[]='Sexo obligatorio.';
        if(empty($errores)){ $st=$pdo->prepare("SELECT idUser FROM users_data WHERE email=? AND idUser!=?"); $st->execute([$em,$idE]); if($st->fetch()) $errores[]='Email en uso por otro usuario.'; }
        if(empty($errores)){
            $pdo->prepare("UPDATE users_data SET nombre=?,apellidos=?,email=?,telefono=?,fecha_nacimiento=?,direccion=?,sexo=? WHERE idUser=?")->execute([$n,$ap,$em,$tel,$fn,$dir,$sx,$idE]);
            $pdo->prepare("UPDATE users_login SET rol=? WHERE idUser=?")->execute([$rol,$idE]);
            if(!empty($np)&&strlen($np)>=6) $pdo->prepare("UPDATE users_login SET password=? WHERE idUser=?")->execute([password_hash($np,PASSWORD_DEFAULT),$idE]);
            $ok='Usuario actualizado correctamente.';
        }
    }
    if ($action==='eliminar') {
        $idD=(int)($_POST['idUser']??0);
        if($idD===(int)$_SESSION['idUser']) $errores[]='No puedes eliminarte a ti mismo.';
        else { $pdo->prepare("DELETE FROM users_data WHERE idUser=?")->execute([$idD]); $ok='Usuario eliminado.'; }
    }
}
$usuarios=$pdo->query("SELECT ud.*,ul.usuario,ul.rol FROM users_data ud JOIN users_login ul ON ud.idUser=ul.idUser ORDER BY ud.idUser ASC")->fetchAll();
$editando=null;
if(isset($_GET['editar'])){ $st=$pdo->prepare("SELECT ud.*,ul.usuario,ul.rol FROM users_data ud JOIN users_login ul ON ud.idUser=ul.idUser WHERE ud.idUser=?"); $st->execute([(int)$_GET['editar']]); $editando=$st->fetch(); }
?>
<!DOCTYPE html>
<html lang="es">
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Usuarios | CubiertasChueca</title>
  <link href="https://fonts.googleapis.com/css2?family=Work+Sans:wght@300;400;600&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="css/style.css">
</head>
<body>
<?php include 'includes/navbar.php'; ?>
<main>
<div class="container" style="padding-top:20px">
  <div class="admin-header-php">
    <h1>👥 Gestión de Usuarios</h1>
    <button class="btn-enviar" onclick="document.getElementById('mc').classList.toggle('open')">+ Nuevo usuario</button>
  </div>
  <?php if($ok): ?><div class="alert-php alert-php-success">✅ <?= htmlspecialchars($ok) ?></div><?php endif; ?>
  <?php if(!empty($errores)): ?><div class="alert-php alert-php-danger"><ul style="margin:0;padding-left:20px"><?php foreach($errores as $e): ?><li><?= htmlspecialchars($e) ?></li><?php endforeach; ?></ul></div><?php endif; ?>

  <?php if($editando): ?>
  <div class="php-card mb-3">
    <h2>✏️ Editar: <?= htmlspecialchars($editando['usuario']) ?></h2>
    <form method="POST" action="usuarios-administracion.php">
      <input type="hidden" name="action" value="actualizar">
      <input type="hidden" name="idUser" value="<?= $editando['idUser'] ?>">
      <div class="php-form-row">
        <div class="php-form-group"><label>Nombre *</label><input type="text" name="nombre" value="<?= htmlspecialchars($editando['nombre']) ?>" required></div>
        <div class="php-form-group"><label>Apellidos *</label><input type="text" name="apellidos" value="<?= htmlspecialchars($editando['apellidos']) ?>" required></div>
      </div>
      <div class="php-form-row">
        <div class="php-form-group"><label>Email *</label><input type="email" name="email" value="<?= htmlspecialchars($editando['email']) ?>" required></div>
        <div class="php-form-group"><label>Teléfono *</label><input type="tel" name="telefono" value="<?= htmlspecialchars($editando['telefono']) ?>" required></div>
      </div>
      <div class="php-form-row">
        <div class="php-form-group"><label>Fecha nacimiento *</label><input type="date" name="fecha_nacimiento" value="<?= $editando['fecha_nacimiento'] ?>" required></div>
        <div class="php-form-group"><label>Sexo *</label>
          <select name="sexo" required>
            <option value="Hombre" <?= $editando['sexo']==='Hombre'?'selected':'' ?>>Hombre</option>
            <option value="Mujer"  <?= $editando['sexo']==='Mujer' ?'selected':'' ?>>Mujer</option>
            <option value="Otro"   <?= $editando['sexo']==='Otro'  ?'selected':'' ?>>Otro</option>
          </select></div>
      </div>
      <div class="php-form-row">
        <div class="php-form-group"><label>Dirección</label><input type="text" name="direccion" value="<?= htmlspecialchars($editando['direccion']??'') ?>"></div>
        <div class="php-form-group"><label>Rol *</label>
          <select name="rol" required>
            <option value="user"  <?= $editando['rol']==='user' ?'selected':'' ?>>Usuario</option>
            <option value="admin" <?= $editando['rol']==='admin'?'selected':'' ?>>Admin</option>
          </select></div>
      </div>
      <div class="php-form-group"><label>Nueva contraseña <small class="text-gray">(vacío = no cambiar)</small></label>
        <input type="password" name="password_nueva" minlength="6"></div>
      <div class="d-flex gap-2">
        <button type="submit" class="btn-enviar">💾 Guardar</button>
        <a href="usuarios-administracion.php" class="btn-reset" style="padding:10px 20px;text-decoration:none">Cancelar</a>
      </div>
    </form>
  </div>
  <?php endif; ?>

  <div class="php-card">
    <div style="margin-bottom:12px">
      <input type="text" id="buscador-tabla" placeholder="🔍 Buscar usuario..." style="padding:8px 12px;border:1px solid #ddd;border-radius:4px;font-family:inherit;font-size:14px;width:100%;max-width:300px">
    </div>
    <div class="table-wrap">
      <table>
        <thead><tr><th>#</th><th>Nombre</th><th>Email</th><th>Usuario</th><th>Rol</th><th>Acciones</th></tr></thead>
        <tbody>
          <?php foreach($usuarios as $u): ?>
          <tr>
            <td><?= $u['idUser'] ?></td>
            <td><?= htmlspecialchars($u['nombre'].' '.$u['apellidos']) ?></td>
            <td><?= htmlspecialchars($u['email']) ?></td>
            <td><?= htmlspecialchars($u['usuario']) ?></td>
            <td><span class="badge-php badge-<?= $u['rol'] ?>"><?= $u['rol'] ?></span></td>
            <td>
              <a href="usuarios-administracion.php?editar=<?= $u['idUser'] ?>" class="btn-php btn-php-warning btn-php-sm">✏️ Editar</a>
              <?php if($u['idUser']!=$_SESSION['idUser']): ?>
              <form method="POST" style="display:inline" onsubmit="return confirm('¿Eliminar este usuario?')">
                <input type="hidden" name="action" value="eliminar">
                <input type="hidden" name="idUser" value="<?= $u['idUser'] ?>">
                <button type="submit" class="btn-php btn-php-danger btn-php-sm">🗑️</button>
              </form>
              <?php endif; ?>
            </td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
</main>

<div class="modal-overlay-php" id="mc">
  <div class="modal-php">
    <h3>➕ Nuevo usuario</h3>
    <form method="POST" action="usuarios-administracion.php">
      <input type="hidden" name="action" value="crear">
      <div class="php-form-row">
        <div class="php-form-group"><label>Nombre *</label><input type="text" name="nombre" required></div>
        <div class="php-form-group"><label>Apellidos *</label><input type="text" name="apellidos" required></div>
      </div>
      <div class="php-form-group"><label>Email *</label><input type="email" name="email" required></div>
      <div class="php-form-row">
        <div class="php-form-group"><label>Teléfono *</label><input type="tel" name="telefono" required></div>
        <div class="php-form-group"><label>Fecha nacimiento *</label><input type="date" name="fecha_nacimiento" required></div>
      </div>
      <div class="php-form-row">
        <div class="php-form-group"><label>Sexo *</label>
          <select name="sexo" required><option value="">—</option><option value="Hombre">Hombre</option><option value="Mujer">Mujer</option><option value="Otro">Otro</option></select></div>
        <div class="php-form-group"><label>Rol *</label>
          <select name="rol" required><option value="user">Usuario</option><option value="admin">Admin</option></select></div>
      </div>
      <div class="php-form-group"><label>Dirección</label><input type="text" name="direccion"></div>
      <div class="php-form-group"><label>Usuario *</label><input type="text" name="usuario" required></div>
      <div class="php-form-group"><label>Contraseña *</label><input type="password" name="password" required minlength="6"></div>
      <div class="d-flex gap-2">
        <button type="submit" class="btn-enviar">Crear</button>
        <button type="button" class="btn-reset" onclick="document.getElementById('mc').classList.remove('open')">Cancelar</button>
      </div>
    </form>
  </div>
</div>

<footer><div class="footer-aviso"><p>&copy; <span id="footer-year"></span> CubiertasChueca.</p></div></footer>
<script src="js/main.js"></script>
</body></html>
