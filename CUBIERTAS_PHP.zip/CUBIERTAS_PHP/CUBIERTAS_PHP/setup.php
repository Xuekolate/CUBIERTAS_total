<?php
/* Ejecutar UNA VEZ: http://localhost/cubiertaschueca/setup.php
   Crea el admin por defecto. BORRAR después de usarlo. */
session_start(); require_once 'config/db.php';
$ok=false; $msg='';
try {
    if($pdo->query("SELECT COUNT(*) FROM users_data WHERE email='admin@cubiertaschueca.es'")->fetchColumn()>0){
        $msg='Admin ya existe. Usuario: admin | Contraseña: admin1234'; $ok=true;
    } else {
        $pdo->prepare("INSERT INTO users_data (nombre,apellidos,email,telefono,fecha_nacimiento,direccion,sexo)
            VALUES ('Adrián','Chueca','admin@cubiertaschueca.es','600000000','1990-01-01','Alcorcón, Madrid','Hombre')")->execute();
        $id=$pdo->lastInsertId();
        $pdo->prepare("INSERT INTO users_login (idUser,usuario,password,rol) VALUES (?,?,?,'admin')")
            ->execute([$id,'admin',password_hash('admin1234',PASSWORD_DEFAULT)]);
        // Insertar noticias de ejemplo desde el JSON del proyecto JS
        $noticias_ejemplo = [
            ['La pizarra natural española lidera las exportaciones europeas de materiales de cubierta',
             'España sigue siendo el mayor productor mundial de pizarra natural para cubiertas. Las canteras de Galicia y Castilla y León exportaron más de 400.000 toneladas en 2025.',
             '2026-04-14'],
            ['Nuevas membranas líquidas de poliurea: impermeabilización en frío sin juntas',
             'Los sistemas de impermeabilización con poliurea aplicada en frío están ganando terreno frente a los sistemas tradicionales de láminas asfálticas.',
             '2026-04-08'],
            ['El CTE actualiza los requisitos de aislamiento en cubiertas inclinadas para 2026',
             'El Código Técnico de la Edificación (DB-HE) introduce nuevos valores mínimos de transmitancia térmica para cubiertas inclinadas y planas.',
             '2026-04-01'],
            ['El zinc titanio: el material de cubierta con mayor crecimiento en obra nueva de lujo',
             'El zinc titanio pre-patinado se ha convertido en el material estrella de los proyectos residenciales de alto standing en Madrid y Barcelona.',
             '2026-03-25'],
        ];
        foreach($noticias_ejemplo as $n){
            $pdo->prepare("INSERT INTO noticias (titulo,imagen,texto,fecha,idUser) VALUES (?,?,?,?,?)")
                ->execute([$n[0],'default.jpg',$n[1],$n[2],$id]);
        }
        $msg='Admin creado. Usuario: admin | Contraseña: admin1234'; $ok=true;
    }
}catch(Exception $e){$msg='Error: '.$e->getMessage();}
?><!DOCTYPE html><html lang="es"><head><meta charset="UTF-8"><title>Setup CubiertasChueca</title>
<style>body{font-family:'Work Sans',Arial,sans-serif;background:#f4f4f4;display:flex;align-items:center;justify-content:center;min-height:100vh;margin:0}
.box{background:white;padding:40px;border-radius:8px;box-shadow:0 2px 12px rgba(0,0,0,.1);text-align:center;max-width:460px}
h2{color:<?php echo $ok?'#28a745':'#dc3545';?>}a{color:#e94560;}</style></head>
<body><div class="box"><h2><?php echo $ok?'✓ Completado':'✗ Error';?></h2>
<p><?php echo htmlspecialchars($msg);?></p>
<?php if($ok):?><p style="margin-top:16px"><a href="index.php">Ir al inicio</a> · <a href="login.php">Iniciar sesión</a></p>
<p style="color:#dc3545;font-size:13px;margin-top:16px">⚠ Borra este archivo (setup.php) ahora.</p><?php endif;?>
</div></body></html>
