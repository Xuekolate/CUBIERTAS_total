<?php
$conn = new mysqli('localhost', 'adrian', '1234');
if ($conn->connect_error) {
    die('Error: ' . $conn->connect_error);
} else {
    echo 'Conexión correcta con adrian';
}

$conn2 = new mysqli('localhost', 'root', 'root');
if ($conn2->connect_error) {
    die('<br>Error root: ' . $conn2->connect_error);
} else {
    echo '<br>Conexión correcta con root';
}

phpinfo();
?>