<?php
/* ============================================================
   index.php — Página de inicio
   BASADO en el index.html original del proyecto JS Avanzado.
   CAMBIOS MÍNIMOS respecto al original:
   1. Añadido session_start() para saber si hay sesión activa
   2. Menú estático sustituido por include 'includes/navbar.php'
      que muestra los enlaces de login/registro/perfil según el rol
   3. Las noticias siguen cargándose con AJAX desde noticias.js,
      pero ahora apunta a api/noticias.php en lugar de data/noticias.json
   El resto del HTML, CSS y JS es IDÉNTICO al original.
   ============================================================ */
session_start();
require_once 'config/db.php';
?>
<!DOCTYPE html>
<html lang="es">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CubiertasChueca</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Work+Sans:wght@300;400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css">
  </head>
  <body>

    <?php
    /* Navbar dinámica: muestra login/registro si no hay sesión,
       o perfil/citas/admin según el rol del usuario logueado */
    include 'includes/navbar.php';
    ?>

    <main class="pagina-inicio">
      <h1>Cubiertas Chueca — más de 3 generaciones haciendo cubiertas e impermeabilizaciones en Madrid</h1>

      <!-- Sección 1: Pizarra -->
      <section>
        <article>
          <h2>Cubiertas y tejados de Pizarra</h2>
          <p>Instalación y restauración de cubiertas con pizarra natural española. Material con durabilidad superior a 100 años, resistente al hielo y al fuego, ideal tanto para obra nueva como para la rehabilitación de edificios históricos.</p>
          <ul class="lista-caracteristicas">
            <li>Durabilidad +100 años</li>
            <li>Resistente al fuego y al hielo</li>
            <li>Mantenimiento mínimo</li>
            <li>Material natural y sostenible</li>
            <li>Ideal para edificios históricos</li>
          </ul>
          <figure>
            <img src="images/cubierta_Pizarra.jpg" alt="Cubierta de pizarra natural" class="foto" width="800" height="533">
            <figcaption>Cubierta de pizarra natural instalada en Madrid</figcaption>
          </figure>
        </article>
      </section>

      <!-- Sección 2: Metales -->
      <section>
        <article>
          <h2>Cubiertas de Zinc, Cobre y Plomo</h2>
          <p>Trabajamos en lámina de zinc, cobre y plomo para cubiertas de alto valor estético. Soluciones para obra nueva y rehabilitación con una vida útil de entre 80 y 100 años y un mantenimiento mínimo.</p>
          <ul class="lista-caracteristicas">
            <li>Vida útil 80-100 años</li>
            <li>Zinc, cobre o plomo a medida</li>
            <li>Acabado estético premium</li>
            <li>Bajo peso estructural</li>
            <li>Apto para rehabilitación</li>
          </ul>
          <figure>
            <img src="images/Cubierta_Zinc.jpg" alt="Cubierta de zinc" class="foto" width="800" height="533">
            <figcaption>Cubierta de zinc instalada en edificio residencial</figcaption>
          </figure>
        </article>
      </section>

      <!-- Sección 3: Impermeabilizaciones -->
      <section>
        <article>
          <h2>Impermeabilizaciones y Reparaciones</h2>
          <p>Sistemas de impermeabilización en cubiertas planas, terrazas y balcones. Realizamos diagnóstico y reparación de humedades con materiales de primera calidad y más de 15 años de garantía.</p>
          <ul class="lista-caracteristicas">
            <li>Membrana continua sin juntas</li>
            <li>+25 años de vida útil</li>
            <li>Resistencia UV y temperatura</li>
            <li>15 años de garantía en obra</li>
            <li>Diagnóstico gratuito</li>
          </ul>
          <figure>
            <img src="images/impermeabilizacion.jpg" alt="Impermeabilización en cubierta plana" class="foto" width="800" height="533">
            <figcaption>Trabajo de impermeabilización en cubierta plana</figcaption>
          </figure>
        </article>
      </section>

      <!-- Sección 4: Valores -->
      <section>
        <h2>Valores y Cualidades</h2>
        <ul id="cualidades">
          <li>
            <h3>Experiencia</h3>
            <img class="logo" src="images/worker-career-svgrepo-com.png" alt="Icono experiencia" width="50" height="50">
            <p>Más de 50 años de experiencia en el sector</p>
          </li>
          <li>
            <h3>Compromiso</h3>
            <img class="logo" src="images/hands-helping-svgrepo-com.png" alt="Icono compromiso" width="50" height="50">
            <p>Compromiso de calidad con los mejores materiales del sector</p>
          </li>
          <li>
            <h3>Atención</h3>
            <img class="logo" src="images/users-svgrepo-com.png" alt="Icono atención" width="50" height="50">
            <p>Atención personalizada adaptada a cada cliente</p>
          </li>
          <li>
            <h3>Garantía</h3>
            <img class="logo" src="images/document-svgrepo-com.png" alt="Icono garantía" width="50" height="50">
            <p>Trabajos con más de 15 años de garantía</p>
          </li>
        </ul>
      </section>

      <!-- Sección 5: Noticias cargadas con AJAX desde api/noticias.php -->
      <section>
        <h2>Actualidad del sector</h2>
        <p id="noticias-loading">Cargando noticias...</p>
        <!-- noticias.js inserta aquí las tarjetas via AJAX -->
        <section id="noticias-grid" aria-label="Noticias del sector"></section>
      </section>

      <?php if (isset($_SESSION['rol']) && $_SESSION['rol'] === 'user'): ?>
      <!-- Sección extra solo para usuarios logueados: acceso rápido a citas -->
      <section>
        <h2>¿Necesitas una visita técnica?</h2>
        <p>Hola, <?= htmlspecialchars($_SESSION['nombre']) ?>. Solicita una cita con nuestro equipo y te asesoramos sin compromiso.</p>
        <p style="margin-top:12px">
          <a href="citaciones.php" class="btn-enviar">📅 Ver mis citas</a>
        </p>
      </section>
      <?php endif; ?>
    </main>

    <!-- Footer idéntico al original -->
    <footer>
      <section>
        <h4>Redes sociales</h4>
        <nav class="footer-redes" aria-label="Redes sociales">
          <a href="https://www.facebook.com/" target="_blank">
            <img src="images/logo-facebook-svgrepo-com.png" alt="Facebook" width="28" height="28">
          </a>
          <a href="https://www.instagram.com/" target="_blank">
            <img src="images/Instagram.png" alt="Instagram" width="28" height="28">
          </a>
          <a href="https://www.whatsapp.com/" target="_blank">
            <img src="images/logo-whatsapp-svgrepo-com.png" alt="WhatsApp" width="28" height="28">
          </a>
        </nav>
      </section>
      <section>
        <h4>Contacto</h4>
        <address>
          <p>C/ Sorbesopas Nº 20, Alcorcón 28921</p>
          <p>Tel: 600 000 000</p>
          <p>info@cubiertaschueca.es</p>
        </address>
      </section>
      <nav class="navegacion" aria-label="Navegación footer">
        <h4>Navegación</h4>
        <ul style="list-style:none;padding-top:5%">
          <li><a href="index.php"           style="color:#ccc">Inicio</a></li>
          <li><a href="views/galeria.php"  style="color:#ccc">Galería</a></li>
          <li><a href="views/presupuesto.php" style="color:#ccc">Presupuesto</a></li>
          <li><a href="views/contacto.php" style="color:#ccc">Contacto</a></li>
          <?php if (!isset($_SESSION['rol'])): ?>
          <li><a href="registro.php"        style="color:#ccc">Registrarse</a></li>
          <li><a href="login.php"           style="color:#ccc">Iniciar sesión</a></li>
          <?php elseif ($_SESSION['rol']==='user'): ?>
          <li><a href="citaciones.php"      style="color:#ccc">Mis citas</a></li>
          <li><a href="perfil.php"          style="color:#ccc">Mi perfil</a></li>
          <?php endif; ?>
        </ul>
      </nav>
      <div class="footer-aviso">
        <p>&copy; <span id="footer-year"></span> CubiertasChueca. Todos los derechos reservados.</p>
        <p><a href="#">Aviso legal</a> · <a href="#">Política de privacidad</a></p>
      </div>
    </footer>

    <script src="js/main.js"></script>
    <script src="js/noticias.js"></script>
  </body>
</html>
