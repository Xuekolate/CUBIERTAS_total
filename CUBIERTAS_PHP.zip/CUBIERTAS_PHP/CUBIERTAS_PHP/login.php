<?php
session_start();
require_once 'config/db.php';
if (isset($_SESSION['rol'])) { header('Location: index.php'); exit; }

$msg_ok = '';
if (isset($_SESSION['registro_ok'])) {
    $msg_ok = $_SESSION['registro_ok'];
    unset($_SESSION['registro_ok']);
}
$error = ''; $usuario_val = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $usuario  = trim($_POST['usuario']  ?? '');
    $password = $_POST['password'] ?? '';
    $usuario_val = $usuario;
    if (empty($usuario) || empty($password)) {
        $error = 'Introduce tu usuario y contraseña.';
    } else {
        $st = $pdo->prepare("SELECT ul.idUser,ul.usuario,ul.password,ul.rol,ud.nombre
            FROM users_login ul JOIN users_data ud ON ul.idUser=ud.idUser WHERE ul.usuario=?");
        $st->execute([$usuario]);
        $row = $st->fetch();
        if ($row && password_verify($password, $row['password'])) {
            $_SESSION['idUser']  = $row['idUser'];
            $_SESSION['usuario'] = $row['usuario'];
            $_SESSION['rol']     = $row['rol'];
            $_SESSION['nombre']  = $row['nombre'];
            header('Location: index.php'); exit;
        } else {
            $error = 'Usuario o contraseña incorrectos.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Iniciar sesión | CubiertasChueca</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Work+Sans:wght@300;400;600&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="css/style.css">
</head>
<body>
<?php include 'includes/navbar.php'; ?>
<main>
  <div class="container-sm" style="padding-top:20px;max-width:420px">
    <?php if ($msg_ok): ?><div class="alert-php alert-php-success"><?= htmlspecialchars($msg_ok) ?></div><?php endif; ?>
    <?php if ($error):  ?><div class="alert-php alert-php-danger">❌ <?= htmlspecialchars($error) ?></div><?php endif; ?>
    <div class="php-card">
      <h2>Iniciar sesión</h2>
      <form method="POST" action="login.php">
        <div class="php-form-group">
          <label for="usuario">Usuario</label>
          <input type="text" id="usuario" name="usuario" value="<?= htmlspecialchars($usuario_val) ?>" required autofocus autocomplete="username">
        </div>
        <div class="php-form-group">
          <label for="password">Contraseña</label>
          <input type="password" id="password" name="password" required autocomplete="current-password">
        </div>
        <button type="submit" class="btn-enviar" style="width:100%;margin-top:8px">Entrar</button>
      </form>
      <p class="php-form-link">¿No tienes cuenta? <a href="registro.php">Regístrate gratis</a></p>
    </div>
  </div>
</main>
<footer><div class="footer-aviso"><p>&copy; <span id="footer-year"></span> CubiertasChueca.</p></div></footer>
<script src="js/main.js"></script>
</body></html>
