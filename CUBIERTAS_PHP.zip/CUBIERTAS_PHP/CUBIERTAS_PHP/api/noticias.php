<?php
/* ============================================================
   api/noticias.php — Endpoint AJAX de noticias
   Devuelve las noticias de la BD en formato JSON idéntico
   al que tenía data/noticias.json en el proyecto original.
   Lo llama noticias.js con XMLHttpRequest (AJAX), igual que antes.
   Solo cambia la URL de la petición: data/noticias.json → api/noticias.php
   ============================================================ */
require_once '../config/db.php';

/* Cabecera JSON para que el navegador sepa que es JSON */
header('Content-Type: application/json; charset=utf-8');

$noticias = $pdo->query("
    SELECT n.idNoticia AS id,
           n.titulo,
           n.texto AS descripcion,
           DATE_FORMAT(n.fecha,'%d de %M de %Y') AS fecha,
           n.imagen,
           CONCAT(u.nombre,' ',u.apellidos) AS autor
    FROM noticias n
    JOIN users_data u ON n.idUser = u.idUser
    ORDER BY n.fecha DESC
")->fetchAll();

/* Enviamos el array como JSON — mismo formato que el noticias.json original */
echo json_encode($noticias, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
