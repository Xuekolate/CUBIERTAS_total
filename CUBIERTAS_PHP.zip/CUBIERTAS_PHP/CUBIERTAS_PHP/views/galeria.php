<?php session_start(); ?>
<!DOCTYPE html>
<html lang="es">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Galería | CubiertasChueca</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
      href="https://fonts.googleapis.com/css2?family=Work+Sans:wght@300;400;600&display=swap"
      rel="stylesheet"
    >
    <!-- hoja de estilos del proyecto -->
    <link rel="stylesheet" href="../css/style.css">
  </head>

  <body>
    <!-- Menú de navegación fijo -->
    <?php include '../includes/navbar.php'; ?>

    <main>
      <h1>Galería de trabajos</h1>

      <!-- Grid de imágenes generado dinámicamente por galeria.js -->
      <section id="galeria-grid" aria-label="Galería de trabajos realizados"></section>
    </main>

    <!-- Lightbox: ventana emergente para ver la imagen ampliada -->
    <section
      class="lightbox"
      id="lightbox"
      role="dialog"
      aria-modal="true"
      aria-label="Visor de imagen"
    >
      <figure class="lightbox__contenido">
        <button class="lightbox__cerrar" id="lb-cerrar" aria-label="Cerrar">
          &#x2715;
        </button>
        <button class="lightbox__nav lightbox__nav--prev" id="lb-prev" aria-label="Anterior">
          &#8592;
        </button>
        <img
          class="lightbox__img"
          id="lb-img"
          src="#"
          alt="imagen ampliada"
          width="800"
          height="533"
        >
        <button class="lightbox__nav lightbox__nav--next" id="lb-next" aria-label="Siguiente">
          &#8594;
        </button>
        <figcaption class="lightbox__caption" id="lb-caption"></figcaption>
      </figure>
      <span class="lightbox__contador" id="lb-contador"></span>
    </section>

    <!-- Footer -->
    <footer>
      <section>
        <h2 style="display: none">Pie de página</h2>
        <h3 style="display: none">Redes</h3>
        <h4>Redes sociales</h4>
        <nav class="footer-redes" aria-label="Redes sociales">
          <a href="https://www.facebook.com/" target="_blank">
            <img src="../images/logo-facebook-svgrepo-com.png" alt="Facebook" width="28" height="28">
          </a>
          <a href="https://www.instagram.com/" target="_blank">
            <img src="../images/Instagram.png" alt="Instagram" width="28" height="28">
          </a>
          <a href="https://www.whatsapp.com/" target="_blank">
            <img src="../images/logo-whatsapp-svgrepo-com.png" alt="WhatsApp" width="28" height="28">
          </a>
        </nav>
      </section>
      <section>
        <h4>Contacto</h4>
        <address>
          <p>C/ Sorbesopas Nº 20, Alcorcón 28921</p>
          <p>Tel: 600 000 000</p>
        </address>
      </section>
      <div class="footer-aviso">
        <p>
          &copy; <span id="footer-year"></span> CubiertasChueca. Todos los
          derechos reservados.
        </p>
        <p><a href="#">Aviso legal</a></p>
      </div>
    
    <?php if (!isset($_SESSION['rol'])): ?>
      <section>
        <h4>Mi cuenta</h4>
        <ul style="list-style:none">
          <li><a href="../login.php"    style="color:#ccc">Iniciar sesión</a></li>
          <li><a href="../registro.php" style="color:#ccc">Registrarse</a></li>
        </ul>
      </section>
    <?php elseif ($_SESSION['rol']==='user'): ?>
      <section>
        <h4>Mi cuenta</h4>
        <ul style="list-style:none">
          <li><a href="../citaciones.php" style="color:#ccc">Mis citas</a></li>
          <li><a href="../perfil.php"     style="color:#ccc">Mi perfil</a></li>
          <li><a href="../logout.php"     style="color:#ccc">Cerrar sesión</a></li>
        </ul>
      </section>
    <?php elseif ($_SESSION['rol']==='admin'): ?>
      <section>
        <h4>Administración</h4>
        <ul style="list-style:none">
          <li><a href="../usuarios-administracion.php" style="color:#ccc">Usuarios</a></li>
          <li><a href="../citas-administracion.php"    style="color:#ccc">Citas</a></li>
          <li><a href="../noticias-administracion.php" style="color:#ccc">Noticias</a></li>
          <li><a href="../logout.php"                  style="color:#ccc">Cerrar sesión</a></li>
        </ul>
      </section>
    <?php endif; ?>
    </footer>

    <script src="../js/main.js"></script>
    <script src="../js/galeria.js"></script>
  </body>
</html>
