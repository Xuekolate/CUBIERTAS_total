<?php
// 1. Conexión a la base de datos (subiendo un nivel desde views/ hacia config/)
require_once __DIR__ . '/../config/db.php';

// 2. Consulta SQL de noticias
try {
    // Intentamos la consulta relacionando con la tabla de usuarios
    $sql = "SELECT n.*, u.nombre AS autor 
            FROM noticias n 
            LEFT JOIN usuarios u ON n.usuario_id = u.id 
            ORDER BY n.idnoticia DESC";
    $stmt = $pdo->query($sql);
    $noticias = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    // Si la tabla de usuarios no existe o falla el JOIN,
    // ejecutamos la consulta limpia usando 'idnoticia'
    try {
        $sql = "SELECT * FROM noticias ORDER BY idnoticia DESC";
        $stmt = $pdo->query($sql);
        $noticias = $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $ex) {
        $error_msg = "Error al cargar las noticias: " . $ex->getMessage();
        $noticias = [];
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Noticias | CubiertasChueca</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Work+Sans:wght@300;400;600&display=swap" rel="stylesheet">
  
  <!-- Hoja de estilos del proyecto -->
  <link rel="stylesheet" href="../css/style.css">
</head>
<body>

  <!-- Carga del menú de navegación -->
  <?php 
  if (file_exists(__DIR__ . '/includes/navbar.php')) {
      include_once __DIR__ . '/includes/navbar.php';
  } elseif (file_exists(__DIR__ . '/../includes/navbar.php')) {
      include_once __DIR__ . '/../includes/navbar.php';
  } elseif (file_exists(__DIR__ . '/navbar.php')) {
      include_once __DIR__ . '/navbar.php';
  }
  ?>

  <main class="pagina-inicio">
    <h1>Actualidad del sector</h1>

    <section>
      <h2>Últimas Noticias y Novedades</h2>
      
      <?php if (isset($error_msg)): ?>
        <div class="alert-php alert-php-danger"><?= htmlspecialchars($error_msg) ?></div>
      <?php endif; ?>

      <!-- Reutilizamos el grid e estructura de tarjetas de style.css -->
      <div id="noticias-grid" style="padding: 10px 0;">
        <?php if (!empty($noticias)): ?>
          <?php foreach ($noticias as $noticia): ?>
            <article class="noticia-card">
              <!-- Etiqueta superior o Autor -->
              <span>
                Por: <?= htmlspecialchars($noticia['autor'] ?? 'Administrador') ?>
              </span>

              <!-- Título de la noticia -->
              <h3><?= htmlspecialchars($noticia['titulo'] ?? 'Sin título') ?></h3>

              <!-- Foto de la noticia (si existe) -->
              <?php if (!empty($noticia['foto'])): ?>
                <img src="../uploads/<?= htmlspecialchars($noticia['foto']) ?>" 
                     alt="<?= htmlspecialchars($noticia['titulo'] ?? 'Foto noticia') ?>" 
                     class="foto" 
                     style="max-width: 100%; height: auto; border-radius: 4px; margin: 10px 0;">
              <?php endif; ?>

              <!-- Texto de la noticia -->
              <p><?= nl2br(htmlspecialchars($noticia['texto'] ?? $noticia['contenido'] ?? '')) ?></p>

              <!-- Fecha de publicación -->
              <div class="fecha">
                Publicado el: 
                <?= isset($noticia['fecha']) ? date('d/m/Y H:i', strtotime($noticia['fecha'])) : 'Reciente' ?>
              </div>
            </article>
          <?php endforeach; ?>
        <?php else: ?>
          <p id="noticias-loading">No hay noticias publicadas en este momento.</p>
        <?php endif; ?>
      </div>
    </section>
  </main>

  <!-- Footer exacto del proyecto -->
  <footer>
    <section>
      <h2 style="display: none">Pie de página</h2>
      <h3 style="display: none">Redes</h3>
      <h4>Redes sociales</h4>
      <nav class="footer-redes" aria-label="Redes sociales">
        <a href="https://www.facebook.com/" target="_blank">
          <img src="../images/logo-facebook-svgrepo-com.png" alt="Facebook" width="28" height="28">
        </a>
        <a href="https://www.instagram.com/" target="_blank">
          <img src="../images/Instagram.png" alt="Instagram" width="28" height="28">
        </a>
        <a href="https://www.whatsapp.com/" target="_blank">
          <img src="../images/logo-whatsapp-svgrepo-com.png" alt="WhatsApp" width="28" height="28">
        </a>
      </nav>
    </section>

    <section>
      <h4>Contacto</h4>
      <address>
        <p>C/ Sorbesopas Nº 20, Alcorcón 28921</p>
        <p>Tel: 600 000 000</p>
      </address>
    </section>

    <div class="footer-aviso">
      <p>&copy; <span id="footer-year"></span> CubiertasChueca. Todos los derechos reservados.</p>
      <p><a href="#">Aviso legal</a></p>
    </div>
  </footer>

  <script src="../js/main.js"></script>
</body>
</html>