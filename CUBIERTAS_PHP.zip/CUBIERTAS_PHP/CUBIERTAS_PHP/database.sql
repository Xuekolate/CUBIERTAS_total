-- ============================================================
-- CubiertasChueca - Proyecto Final PHP (integrado con JS Avanzado)
-- Importar en phpMyAdmin, luego ejecutar setup.php UNA VEZ
-- ============================================================
CREATE DATABASE IF NOT EXISTS cubiertaschueca CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE cubiertaschueca;

CREATE TABLE IF NOT EXISTS users_data (
    idUser           INT          NOT NULL AUTO_INCREMENT,
    nombre           VARCHAR(100) NOT NULL,
    apellidos        VARCHAR(150) NOT NULL,
    email            VARCHAR(150) NOT NULL UNIQUE,
    telefono         VARCHAR(20)  NOT NULL,
    fecha_nacimiento DATE         NOT NULL,
    direccion        TEXT,
    sexo             ENUM('Hombre','Mujer','Otro') NOT NULL,
    PRIMARY KEY (idUser)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS users_login (
    idLogin  INT          NOT NULL AUTO_INCREMENT,
    idUser   INT          NOT NULL UNIQUE,
    usuario  VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    rol      ENUM('admin','user') NOT NULL DEFAULT 'user',
    PRIMARY KEY (idLogin),
    CONSTRAINT fk_login_user FOREIGN KEY (idUser) REFERENCES users_data(idUser) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS citas (
    idCita      INT  NOT NULL AUTO_INCREMENT,
    idUser      INT  NOT NULL,
    fecha_cita  DATE NOT NULL,
    motivo_cita TEXT,
    PRIMARY KEY (idCita),
    CONSTRAINT fk_cita_user FOREIGN KEY (idUser) REFERENCES users_data(idUser) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS noticias (
    idNoticia INT          NOT NULL AUTO_INCREMENT,
    titulo    VARCHAR(255) NOT NULL UNIQUE,
    imagen    VARCHAR(255) NOT NULL,
    texto     LONGTEXT     NOT NULL,
    fecha     DATE         NOT NULL,
    idUser    INT          NOT NULL,
    PRIMARY KEY (idNoticia),
    CONSTRAINT fk_noticia_user FOREIGN KEY (idUser) REFERENCES users_data(idUser) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
