<?php
session_start(); require_once 'config/db.php';
if (!isset($_SESSION['rol']) || $_SESSION['rol'] !== 'admin') { header('Location: index.php'); exit; }
$errores=[]; $ok=''; $hoy=date('Y-m-d');
$usuarios=$pdo->query("SELECT ud.idUser,ud.nombre,ud.apellidos FROM users_data ud JOIN users_login ul ON ud.idUser=ul.idUser ORDER BY ud.nombre")->fetchAll();
$idUserSel=isset($_GET['usuario'])?(int)$_GET['usuario']:(isset($_POST['idUserSel'])?(int)$_POST['idUserSel']:0);

if ($_SERVER['REQUEST_METHOD']==='POST') {
    $action=$_POST['action']??''; $idUserSel=(int)($_POST['idUserSel']??0);
    if ($action==='crear') {
        $fecha=trim($_POST['fecha_cita']??''); $motivo=trim($_POST['motivo_cita']??'');
        if(!$idUserSel) $errores[]='Selecciona un usuario.';
        if(empty($fecha)) $errores[]='La fecha es obligatoria.';
        if(empty($errores)){ $pdo->prepare("INSERT INTO citas (idUser,fecha_cita,motivo_cita) VALUES (?,?,?)")->execute([$idUserSel,$fecha,$motivo]); $ok='Cita creada.'; }
    }
    if ($action==='editar') {
        $idCita=(int)($_POST['idCita']??0); $fecha=trim($_POST['fecha_cita']??''); $motivo=trim($_POST['motivo_cita']??'');
        if(empty($fecha)) $errores[]='La fecha es obligatoria.';
        if(empty($errores)){ $pdo->prepare("UPDATE citas SET fecha_cita=?,motivo_cita=? WHERE idCita=?")->execute([$fecha,$motivo,$idCita]); $ok='Cita actualizada.'; }
    }
    if ($action==='eliminar') {
        $idCita=(int)($_POST['idCita']??0);
        $pdo->prepare("DELETE FROM citas WHERE idCita=?")->execute([$idCita]); $ok='Cita eliminada.';
    }
}
$citas=[]; $usuarioSel=null;
if ($idUserSel) {
    $st=$pdo->prepare("SELECT nombre,apellidos FROM users_data WHERE idUser=?"); $st->execute([$idUserSel]); $usuarioSel=$st->fetch();
    $st=$pdo->prepare("SELECT * FROM citas WHERE idUser=? ORDER BY fecha_cita ASC"); $st->execute([$idUserSel]); $citas=$st->fetchAll();
}
$editando=null;
if (isset($_GET['editar'])) {
    $st=$pdo->prepare("SELECT * FROM citas WHERE idCita=?"); $st->execute([(int)$_GET['editar']]); $editando=$st->fetch();
    if($editando) $idUserSel=$editando['idUser'];
}
?>
<!DOCTYPE html>
<html lang="es">
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Citas Admin | CubiertasChueca</title>
  <link href="https://fonts.googleapis.com/css2?family=Work+Sans:wght@300;400;600&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="css/style.css">
</head>
<body>
<?php include 'includes/navbar.php'; ?>
<main>
<div class="container" style="padding-top:20px">
  <div class="admin-header-php"><h1>📅 Gestión de Citas</h1></div>
  <?php if($ok): ?><div class="alert-php alert-php-success">✅ <?= htmlspecialchars($ok) ?></div><?php endif; ?>
  <?php if(!empty($errores)): ?><div class="alert-php alert-php-danger"><ul style="margin:0;padding-left:20px"><?php foreach($errores as $e): ?><li><?= htmlspecialchars($e) ?></li><?php endforeach; ?></ul></div><?php endif; ?>

  <div class="php-card" style="margin-bottom:20px">
    <h2>Seleccionar usuario</h2>
    <form method="GET" action="citas-administracion.php" class="d-flex gap-2 align-center">
      <select name="usuario" style="padding:8px 12px;border:1px solid #ddd;border-radius:4px;font-family:inherit;font-size:14px;flex:1;min-width:200px">
        <option value="">— Selecciona un usuario —</option>
        <?php foreach($usuarios as $u): ?>
          <option value="<?= $u['idUser'] ?>" <?= $u['idUser']==$idUserSel?'selected':'' ?>><?= htmlspecialchars($u['nombre'].' '.$u['apellidos']) ?></option>
        <?php endforeach; ?>
      </select>
      <button type="submit" class="btn-enviar" style="white-space:nowrap">Ver citas</button>
    </form>
  </div>

  <?php if($idUserSel && $usuarioSel): ?>
  <?php if($editando): ?>
  <div class="php-card" style="margin-bottom:20px">
    <h2>✏️ Editar cita</h2>
    <form method="POST" action="citas-administracion.php">
      <input type="hidden" name="action" value="editar">
      <input type="hidden" name="idCita" value="<?= $editando['idCita'] ?>">
      <input type="hidden" name="idUserSel" value="<?= $idUserSel ?>">
      <div class="php-form-row">
        <div class="php-form-group"><label>Fecha *</label><input type="date" name="fecha_cita" value="<?= $editando['fecha_cita'] ?>" required></div>
        <div class="php-form-group"><label>Motivo</label><input type="text" name="motivo_cita" value="<?= htmlspecialchars($editando['motivo_cita']??'') ?>"></div>
      </div>
      <div class="d-flex gap-2">
        <button type="submit" class="btn-enviar">💾 Guardar</button>
        <a href="citas-administracion.php?usuario=<?= $idUserSel ?>" class="btn-reset" style="padding:10px 20px;text-decoration:none">Cancelar</a>
      </div>
    </form>
  </div>
  <?php endif; ?>

  <div class="php-card">
    <div class="d-flex justify-between align-center" style="margin-bottom:16px">
      <h2 style="margin:0">Citas de: <?= htmlspecialchars($usuarioSel['nombre'].' '.$usuarioSel['apellidos']) ?></h2>
      <button class="btn-enviar btn-php-sm" onclick="document.getElementById('mc').classList.toggle('open')">+ Nueva cita</button>
    </div>
    <?php if(empty($citas)): ?>
      <div class="alert-php alert-php-info">Sin citas registradas.</div>
    <?php else: ?>
      <?php foreach($citas as $c): $pasada=$c['fecha_cita']<$hoy; ?>
      <div class="cita-item <?= $pasada?'pasada':'' ?>">
        <div class="cita-date"><?= date('d/m',strtotime($c['fecha_cita'])) ?><br><small><?= date('Y',strtotime($c['fecha_cita'])) ?></small></div>
        <div class="cita-info">
          <h4><?= $pasada?'📋 Realizada':'🔜 Pendiente' ?></h4>
          <p><?= !empty($c['motivo_cita'])?htmlspecialchars($c['motivo_cita']):'<em>Sin motivo</em>' ?></p>
        </div>
        <div class="cita-actions">
          <a href="citas-administracion.php?editar=<?= $c['idCita'] ?>&usuario=<?= $idUserSel ?>" class="btn-php btn-php-warning btn-php-sm">✏️</a>
          <form method="POST" style="display:inline" onsubmit="return confirm('¿Eliminar?')">
            <input type="hidden" name="action" value="eliminar">
            <input type="hidden" name="idCita" value="<?= $c['idCita'] ?>">
            <input type="hidden" name="idUserSel" value="<?= $idUserSel ?>">
            <button type="submit" class="btn-php btn-php-danger btn-php-sm">🗑️</button>
          </form>
        </div>
      </div>
      <?php endforeach; ?>
    <?php endif; ?>
  </div>
  <?php endif; ?>
</div>
</main>

<div class="modal-overlay-php" id="mc">
  <div class="modal-php">
    <h3>📅 Nueva cita para <?= htmlspecialchars(($usuarioSel['nombre']??'').' '.($usuarioSel['apellidos']??'')) ?></h3>
    <form method="POST" action="citas-administracion.php">
      <input type="hidden" name="action" value="crear">
      <input type="hidden" name="idUserSel" value="<?= $idUserSel ?>">
      <div class="php-form-group"><label>Fecha *</label><input type="date" name="fecha_cita" required></div>
      <div class="php-form-group"><label>Motivo</label><textarea name="motivo_cita" rows="3"></textarea></div>
      <div class="d-flex gap-2">
        <button type="submit" class="btn-enviar">Crear cita</button>
        <button type="button" class="btn-reset" onclick="document.getElementById('mc').classList.remove('open')">Cancelar</button>
      </div>
    </form>
  </div>
</div>
<footer><div class="footer-aviso"><p>&copy; <span id="footer-year"></span> CubiertasChueca.</p></div></footer>
<script src="js/main.js"></script>
</body></html>
