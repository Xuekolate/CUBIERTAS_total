<?php
// 1. Incluimos el archivo de conexión a la base de datos
require_once __DIR__ . '/db.php';

// 2. Consulta SQL para traer la noticia + foto + nombre del autor
try {
    // Consulta relacionando la tabla de noticias con la de usuarios
    // Ajusta los nombres de tablas/campos ('noticias', 'usuarios', 'autor_id', etc.) según tu base de datos
    $sql = "SELECT n.titulo, n.fecha_publicacion, n.texto, n.foto, u.nombre AS autor 
            FROM noticias n 
            JOIN usuarios u ON n.usuario_id = u.id 
            ORDER BY n.fecha_publicacion DESC";

    $stmt = $pdo->query($sql);
    $noticias = $stmt->fetchAll();
} catch (PDOException $e) {
    // En caso de error en la consulta (ej. si cambian los nombres de las columnas)
    $error_msg = "Error al cargar las noticias: " . $e->getMessage();
    $noticias = [];
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Noticias - Cubiertas Chueca</title>
    <style>
        body { font-family: Arial, sans-serif; background-color: #f4f6f9; margin: 0; padding: 20px; }
        .container { max-width: 900px; margin: 0 auto; }
        h1 { text-align: center; color: #333; margin-bottom: 30px; }
        
        /* Estilos para las tarjetas de noticias */
        .noticia-card {
            background: #ffffff;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            margin-bottom: 25px;
            padding: 20px;
            overflow: hidden;
        }
        .noticia-header { border-bottom: 1px solid #eee; padding-bottom: 10px; margin-bottom: 15px; }
        .noticia-titulo { color: #1a252f; margin: 0 0 8px 0; font-size: 1.5em; }
        .noticia-meta { font-size: 0.85em; color: #7f8c8d; }
        .noticia-meta strong { color: #2c3e50; }
        
        .noticia-cuerpo { display: flex; gap: 20px; flex-wrap: wrap; margin-top: 15px; }
        .noticia-foto { max-width: 300px; width: 100%; height: auto; border-radius: 6px; object-fit: cover; }
        .noticia-texto { flex: 1; min-width: 250px; line-height: 1.6; color: #444; }
        
        .alert-error { background-color: #f8d7da; color: #721c24; padding: 15px; border-radius: 5px; margin-bottom: 20px; }
        .no-noticias { text-align: center; color: #666; font-style: italic; background: #fff; padding: 20px; border-radius: 8px; }
    </style>
</head>
<body>

<div class="container">
    <h1>Noticias y Novedades</h1>

    <?php if (isset($error_msg)): ?>
        <div class="alert-error"><?= htmlspecialchars($error_msg) ?></div>
    <?php endif; ?>

    <?php if (!empty($noticias)): ?>
        <?php foreach ($noticias as $noticia): ?>
            <article class="noticia-card">
                <div class="noticia-header">
                    <!-- Título -->
                    <h2 class="noticia-titulo"><?= htmlspecialchars($noticia['titulo']) ?></h2>
                    <div class="noticia-meta">
                        <!-- Fecha de publicación -->
                        Publicado el: <span><?= date('d/m/Y H:i', strtotime($noticia['fecha_publicacion'])) ?></span> 
                        | 
                        <!-- Nombre del usuario autor -->
                        Por: <strong><?= htmlspecialchars($noticia['autor']) ?></strong>
                    </div>
                </div>

                <div class="noticia-cuerpo">
                    <!-- Foto de la noticia -->
                    <?php if (!empty($noticia['foto'])): ?>
                        <img src="uploads/<?= htmlspecialchars($noticia['foto']) ?>" alt="<?= htmlspecialchars($noticia['titulo']) ?>" class="noticia-foto">
                    <?php endif; ?>

                    <!-- Texto de la noticia -->
                    <div class="noticia-texto">
                        <p><?= nl2br(htmlspecialchars($noticia['texto'])) ?></p>
                    </div>
                </div>
            </article>
        <?php endforeach; ?>
    <?php else: ?>
        <p class="no-noticias">No hay noticias disponibles en este momento.</p>
    <?php endif; ?>
</div>

</body>
</html>