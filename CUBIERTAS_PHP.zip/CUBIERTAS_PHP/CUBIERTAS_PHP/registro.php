<?php
/* ============================================================
   registro.php — Registro de nuevos usuarios
   Al registrarse correctamente REDIRIGE al login (enunciado).
   Mismo estilo visual que el resto del proyecto CubiertasChueca.
   ============================================================ */
session_start();
require_once 'config/db.php';
if (isset($_SESSION['rol'])) { header('Location: index.php'); exit; }

$errores = [];
$datos   = ['nombre'=>'','apellidos'=>'','email'=>'','telefono'=>'',
            'fecha_nacimiento'=>'','direccion'=>'','sexo'=>'','usuario'=>''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre           = trim($_POST['nombre']           ?? '');
    $apellidos        = trim($_POST['apellidos']        ?? '');
    $email            = trim($_POST['email']            ?? '');
    $telefono         = trim($_POST['telefono']         ?? '');
    $fecha_nacimiento = trim($_POST['fecha_nacimiento'] ?? '');
    $direccion        = trim($_POST['direccion']        ?? '');
    $sexo             = trim($_POST['sexo']             ?? '');
    $usuario          = trim($_POST['usuario']          ?? '');
    $password         = $_POST['password']         ?? '';
    $confirm          = $_POST['confirm_password'] ?? '';

    $datos = compact('nombre','apellidos','email','telefono','fecha_nacimiento','direccion','sexo','usuario');

    if (empty($nombre))           $errores[] = 'El nombre es obligatorio.';
    if (empty($apellidos))        $errores[] = 'Los apellidos son obligatorios.';
    if (empty($email))            $errores[] = 'El email es obligatorio.';
    elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errores[] = 'El email no tiene un formato válido.';
    if (empty($telefono))         $errores[] = 'El teléfono es obligatorio.';
    if (empty($fecha_nacimiento)) $errores[] = 'La fecha de nacimiento es obligatoria.';
    if (empty($sexo))             $errores[] = 'El sexo es obligatorio.';
    if (empty($usuario))          $errores[] = 'El nombre de usuario es obligatorio.';
    if (strlen($password) < 6)    $errores[] = 'La contraseña debe tener al menos 6 caracteres.';
    if ($password !== $confirm)   $errores[] = 'Las contraseñas no coinciden.';

    if (empty($errores)) {
        $st = $pdo->prepare("SELECT idUser FROM users_data WHERE email=?");
        $st->execute([$email]);
        if ($st->fetch()) $errores[] = 'Este email ya está registrado.';
        $st = $pdo->prepare("SELECT idLogin FROM users_login WHERE usuario=?");
        $st->execute([$usuario]);
        if ($st->fetch()) $errores[] = 'Este nombre de usuario ya está en uso.';
    }

    if (empty($errores)) {
        try {
            $pdo->beginTransaction();
            $pdo->prepare("INSERT INTO users_data (nombre,apellidos,email,telefono,fecha_nacimiento,direccion,sexo) VALUES (?,?,?,?,?,?,?)")
                ->execute([$nombre,$apellidos,$email,$telefono,$fecha_nacimiento,$direccion,$sexo]);
            $idUser = $pdo->lastInsertId();
            $pdo->prepare("INSERT INTO users_login (idUser,usuario,password,rol) VALUES (?,?,?,'user')")
                ->execute([$idUser,$usuario,password_hash($password,PASSWORD_DEFAULT)]);
            $pdo->commit();
            $_SESSION['registro_ok'] = '✅ Cuenta creada correctamente. Ya puedes iniciar sesión.';
            header('Location: login.php');
            exit;
        } catch (Exception $e) {
            $pdo->rollBack();
            $errores[] = 'Error al registrar. Inténtalo de nuevo.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Registrarse | CubiertasChueca</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Work+Sans:wght@300;400;600&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="css/style.css">
</head>
<body>
<?php include 'includes/navbar.php'; ?>
<main>
  <div class="container-sm" style="padding-top:20px">

    <?php if (!empty($errores)): ?>
    <div class="alert-php alert-php-danger">
      <strong>Corrige los siguientes errores:</strong>
      <ul style="margin-top:8px;padding-left:20px">
        <?php foreach($errores as $e): ?><li><?= htmlspecialchars($e) ?></li><?php endforeach; ?>
      </ul>
    </div>
    <?php endif; ?>

    <div class="php-card">
      <h2>Crear cuenta</h2>
      <form method="POST" action="registro.php" novalidate>
        <div class="php-form-row">
          <div class="php-form-group">
            <label for="nombre">Nombre *</label>
            <input type="text" id="nombre" name="nombre" value="<?= htmlspecialchars($datos['nombre']) ?>" required maxlength="100">
          </div>
          <div class="php-form-group">
            <label for="apellidos">Apellidos *</label>
            <input type="text" id="apellidos" name="apellidos" value="<?= htmlspecialchars($datos['apellidos']) ?>" required maxlength="150">
          </div>
        </div>
        <div class="php-form-group">
          <label for="email">Correo electrónico *</label>
          <input type="email" id="email" name="email" value="<?= htmlspecialchars($datos['email']) ?>" required maxlength="150">
        </div>
        <div class="php-form-row">
          <div class="php-form-group">
            <label for="telefono">Teléfono *</label>
            <input type="tel" id="telefono" name="telefono" value="<?= htmlspecialchars($datos['telefono']) ?>" required maxlength="20">
          </div>
          <div class="php-form-group">
            <label for="fecha_nacimiento">Fecha de nacimiento *</label>
            <input type="date" id="fecha_nacimiento" name="fecha_nacimiento" value="<?= htmlspecialchars($datos['fecha_nacimiento']) ?>" required>
          </div>
        </div>
        <div class="php-form-row">
          <div class="php-form-group">
            <label for="sexo">Sexo *</label>
            <select id="sexo" name="sexo" required>
              <option value="">— Selecciona —</option>
              <option value="Hombre" <?= $datos['sexo']==='Hombre'?'selected':'' ?>>Hombre</option>
              <option value="Mujer"  <?= $datos['sexo']==='Mujer' ?'selected':'' ?>>Mujer</option>
              <option value="Otro"   <?= $datos['sexo']==='Otro'  ?'selected':'' ?>>Otro</option>
            </select>
          </div>
          <div class="php-form-group">
            <label for="direccion">Dirección <small class="text-gray">(opcional)</small></label>
            <input type="text" id="direccion" name="direccion" value="<?= htmlspecialchars($datos['direccion']) ?>">
          </div>
        </div>
        <hr style="border:none;border-top:1px solid #eee;margin:4px 0 16px">
        <div class="php-form-group">
          <label for="usuario">Nombre de usuario *</label>
          <input type="text" id="usuario" name="usuario" value="<?= htmlspecialchars($datos['usuario']) ?>" required maxlength="100">
          <p class="php-form-note">⚠️ No se puede cambiar después del registro.</p>
        </div>
        <div class="php-form-row">
          <div class="php-form-group">
            <label for="password">Contraseña *</label>
            <input type="password" id="password" name="password" required minlength="6">
            <!-- Barra de fuerza animada por main.js -->
            <div style="height:5px;background:#eee;border-radius:3px;margin-top:6px;overflow:hidden">
              <div id="barra-fuerza" style="height:100%;width:0;border-radius:3px;transition:width .3s,background .3s"></div>
            </div>
            <p class="php-form-note">Mínimo 6 caracteres</p>
          </div>
          <div class="php-form-group">
            <label for="confirm_password">Confirmar contraseña *</label>
            <input type="password" id="confirm_password" name="confirm_password" required>
          </div>
        </div>
        <button type="submit" class="btn-enviar" style="width:100%;margin-top:8px">Crear cuenta</button>
      </form>
      <p class="php-form-link">¿Ya tienes cuenta? <a href="login.php">Inicia sesión aquí</a></p>
    </div>
  </div>
</main>
<footer>
  <div class="footer-aviso">
    <p>&copy; <span id="footer-year"></span> CubiertasChueca. Todos los derechos reservados.</p>
  </div>
</footer>
<script src="js/main.js"></script>
</body>
</html>
