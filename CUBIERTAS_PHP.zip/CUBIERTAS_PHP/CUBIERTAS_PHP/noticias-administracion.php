<?php
session_start(); require_once 'config/db.php';
if (!isset($_SESSION['rol']) || $_SESSION['rol'] !== 'admin') { header('Location: index.php'); exit; }
$idUser=$_SESSION['idUser']; $errores=[]; $ok='';

function subirImagen($campo, &$errores) {
    if (!isset($_FILES[$campo]) || $_FILES[$campo]['error']===UPLOAD_ERR_NO_FILE) return null;
    if ($_FILES[$campo]['error']!==UPLOAD_ERR_OK) { $errores[]='Error al subir la imagen.'; return false; }
    $ext=strtolower(pathinfo($_FILES[$campo]['name'],PATHINFO_EXTENSION));
    if (!in_array($ext,['jpg','jpeg','png','gif','webp'])) { $errores[]='Formato no permitido.'; return false; }
    $nombre='noticia_'.time().'_'.mt_rand(1000,9999).'.'.$ext;
    if (!move_uploaded_file($_FILES[$campo]['tmp_name'],UPLOAD_DIR.$nombre)) { $errores[]='No se pudo guardar la imagen.'; return false; }
    return $nombre;
}

if ($_SERVER['REQUEST_METHOD']==='POST') {
    $action=$_POST['action']??'';
    if ($action==='crear') {
        $titulo=trim($_POST['titulo']??''); $texto=trim($_POST['texto']??''); $fecha=trim($_POST['fecha']??'');
        if(empty($titulo)) $errores[]='Título obligatorio.';
        if(empty($texto))  $errores[]='Texto obligatorio.';
        if(empty($fecha))  $errores[]='Fecha obligatoria.';
        if(empty($errores)){ $st=$pdo->prepare("SELECT idNoticia FROM noticias WHERE titulo=?"); $st->execute([$titulo]); if($st->fetch()) $errores[]='Ya existe una noticia con ese título.'; }
        $imagen=subirImagen('imagen',$errores);
        if($imagen===null) $errores[]='La imagen es obligatoria.';
        if(empty($errores)){ $pdo->prepare("INSERT INTO noticias (titulo,imagen,texto,fecha,idUser) VALUES (?,?,?,?,?)")->execute([$titulo,$imagen,$texto,$fecha,$idUser]); $ok='Noticia publicada.'; }
    }
    if ($action==='editar') {
        $idN=(int)($_POST['idNoticia']??0); $titulo=trim($_POST['titulo']??''); $texto=trim($_POST['texto']??''); $fecha=trim($_POST['fecha']??'');
        if(empty($titulo)) $errores[]='Título obligatorio.'; if(empty($texto)) $errores[]='Texto obligatorio.'; if(empty($fecha)) $errores[]='Fecha obligatoria.';
        if(empty($errores)){ $st=$pdo->prepare("SELECT idNoticia FROM noticias WHERE titulo=? AND idNoticia!=?"); $st->execute([$titulo,$idN]); if($st->fetch()) $errores[]='Título ya en uso.'; }
        $imgN=subirImagen('imagen',$errores);
        if(empty($errores)){
            if($imgN) $pdo->prepare("UPDATE noticias SET titulo=?,texto=?,fecha=?,imagen=? WHERE idNoticia=?")->execute([$titulo,$texto,$fecha,$imgN,$idN]);
            else      $pdo->prepare("UPDATE noticias SET titulo=?,texto=?,fecha=? WHERE idNoticia=?")->execute([$titulo,$texto,$fecha,$idN]);
            $ok='Noticia actualizada.';
        }
    }
    if ($action==='eliminar') {
        $idN=(int)($_POST['idNoticia']??0);
        $st=$pdo->prepare("SELECT imagen FROM noticias WHERE idNoticia=?"); $st->execute([$idN]); $img=$st->fetchColumn();
        $pdo->prepare("DELETE FROM noticias WHERE idNoticia=?")->execute([$idN]);
        if($img&&$img!=='default.jpg'&&file_exists(UPLOAD_DIR.$img)) unlink(UPLOAD_DIR.$img);
        $ok='Noticia eliminada.';
    }
}
$noticias=$pdo->query("SELECT n.*,CONCAT(u.nombre,' ',u.apellidos) AS autor FROM noticias n JOIN users_data u ON n.idUser=u.idUser ORDER BY n.fecha DESC")->fetchAll();
$editando=null;
if(isset($_GET['editar'])){ $st=$pdo->prepare("SELECT * FROM noticias WHERE idNoticia=?"); $st->execute([(int)$_GET['editar']]); $editando=$st->fetch(); }
?>
<!DOCTYPE html>
<html lang="es">
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Noticias Admin | CubiertasChueca</title>
  <link href="https://fonts.googleapis.com/css2?family=Work+Sans:wght@300;400;600&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="css/style.css">
</head>
<body>
<?php include 'includes/navbar.php'; ?>
<main>
<div class="container" style="padding-top:20px">
  <div class="admin-header-php">
    <h1>📰 Gestión de Noticias</h1>
    <button class="btn-enviar" onclick="document.getElementById('mc').classList.toggle('open')">+ Nueva noticia</button>
  </div>
  <?php if($ok): ?><div class="alert-php alert-php-success">✅ <?= htmlspecialchars($ok) ?></div><?php endif; ?>
  <?php if(!empty($errores)): ?><div class="alert-php alert-php-danger"><ul style="margin:0;padding-left:20px"><?php foreach($errores as $e): ?><li><?= htmlspecialchars($e) ?></li><?php endforeach; ?></ul></div><?php endif; ?>

  <?php if($editando): ?>
  <div class="php-card" style="margin-bottom:20px">
    <h2>✏️ Editar noticia</h2>
    <form method="POST" action="noticias-administracion.php" enctype="multipart/form-data">
      <input type="hidden" name="action" value="editar">
      <input type="hidden" name="idNoticia" value="<?= $editando['idNoticia'] ?>">
      <div class="php-form-group"><label>Título *</label><input type="text" name="titulo" value="<?= htmlspecialchars($editando['titulo']) ?>" required maxlength="255"></div>
      <div class="php-form-group"><label>Texto *</label><textarea name="texto" rows="5" required><?= htmlspecialchars($editando['texto']) ?></textarea></div>
      <div class="php-form-row">
        <div class="php-form-group"><label>Fecha *</label><input type="date" name="fecha" value="<?= $editando['fecha'] ?>" required></div>
        <div class="php-form-group"><label>Imagen <small class="text-gray">(vacío = mantener actual)</small></label>
          <input type="file" name="imagen" accept="image/*">
          <?php if($editando['imagen']&&$editando['imagen']!=='default.jpg'): ?>
            <p class="php-form-note">Actual: <?= htmlspecialchars($editando['imagen']) ?></p>
          <?php endif; ?></div>
      </div>
      <div class="d-flex gap-2">
        <button type="submit" class="btn-enviar">💾 Guardar</button>
        <a href="noticias-administracion.php" class="btn-reset" style="padding:10px 20px;text-decoration:none">Cancelar</a>
      </div>
    </form>
  </div>
  <?php endif; ?>

  <div class="php-card">
    <div style="margin-bottom:12px">
      <input type="text" id="buscador-tabla" placeholder="🔍 Buscar noticia..."
        style="padding:8px 12px;border:1px solid #ddd;border-radius:4px;font-family:inherit;font-size:14px;width:100%;max-width:300px">
    </div>
    <div class="table-wrap">
      <table>
        <thead><tr><th>#</th><th>Imagen</th><th>Título</th><th>Fecha</th><th>Autor</th><th>Acciones</th></tr></thead>
        <tbody>
          <?php if(empty($noticias)): ?><tr><td colspan="6" style="text-align:center;padding:20px;color:#888">No hay noticias.</td></tr><?php endif; ?>
          <?php foreach($noticias as $n): ?>
          <tr>
            <td><?= $n['idNoticia'] ?></td>
            <td>
              <?php if($n['imagen']!=='default.jpg'&&file_exists('uploads/'.$n['imagen'])): ?>
                <img src="uploads/<?= htmlspecialchars($n['imagen']) ?>" alt="" style="width:60px;height:40px;object-fit:cover;border-radius:4px">
              <?php else: ?><span style="font-size:24px">🏠</span><?php endif; ?>
            </td>
            <td><?= htmlspecialchars($n['titulo']) ?></td>
            <td><?= date('d/m/Y',strtotime($n['fecha'])) ?></td>
            <td><?= htmlspecialchars($n['autor']) ?></td>
            <td>
              <a href="noticias-administracion.php?editar=<?= $n['idNoticia'] ?>" class="btn-php btn-php-warning btn-php-sm">✏️ Editar</a>
              <form method="POST" style="display:inline" onsubmit="return confirm('¿Eliminar esta noticia?')">
                <input type="hidden" name="action" value="eliminar">
                <input type="hidden" name="idNoticia" value="<?= $n['idNoticia'] ?>">
                <button type="submit" class="btn-php btn-php-danger btn-php-sm">🗑️</button>
              </form>
            </td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
</main>

<div class="modal-overlay-php" id="mc">
  <div class="modal-php">
    <h3>📰 Nueva noticia</h3>
    <form method="POST" action="noticias-administracion.php" enctype="multipart/form-data">
      <input type="hidden" name="action" value="crear">
      <div class="php-form-group"><label>Título *</label><input type="text" name="titulo" required maxlength="255"></div>
      <div class="php-form-group"><label>Texto *</label><textarea name="texto" rows="5" required placeholder="Contenido de la noticia..."></textarea></div>
      <div class="php-form-row">
        <div class="php-form-group"><label>Fecha *</label><input type="date" name="fecha" value="<?= date('Y-m-d') ?>" required></div>
        <div class="php-form-group"><label>Imagen *</label><input type="file" name="imagen" accept="image/*" required></div>
      </div>
      <div class="d-flex gap-2">
        <button type="submit" class="btn-enviar">Publicar</button>
        <button type="button" class="btn-reset" onclick="document.getElementById('mc').classList.remove('open')">Cancelar</button>
      </div>
    </form>
  </div>
</div>
<footer><div class="footer-aviso"><p>&copy; <span id="footer-year"></span> CubiertasChueca.</p></div></footer>
<script src="js/main.js"></script>
</body></html>
