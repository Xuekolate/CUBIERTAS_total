/* ============================================================
   noticias.js — Carga dinámica de noticias con AJAX
   CAMBIO RESPECTO AL PROYECTO JS ORIGINAL:
   Antes: cargaba desde 'data/noticias.json' (archivo estático)
   Ahora: carga desde 'api/noticias.php'    (datos dinámicos de la BD)
   El resto del código es IDÉNTICO: mismo XMLHttpRequest, mismo
   JSON.parse, mismo forEach, mismas clases CSS, misma estructura HTML.
   ============================================================ */

document.addEventListener('DOMContentLoaded', function () {

    var contenedor = document.getElementById('noticias-grid');
    var loading    = document.getElementById('noticias-loading');

    if (!contenedor) return; /* Solo ejecutar en index.php */

    /* ── PASO 1: Crear el objeto XMLHttpRequest ── */
    var xhr = new XMLHttpRequest();

    /* ── PASO 2: Configurar la petición ──
       ÚNICO CAMBIO: la URL apunta al endpoint PHP en lugar del JSON estático */
    xhr.open('GET', 'api/noticias.php', true);

    /* ── PASO 3: Definir qué hacer cuando llegue la respuesta ── */
    xhr.onreadystatechange = function () {

        /* readyState 4 = respuesta completa | status 200 = éxito */
        if (xhr.readyState === 4 && xhr.status === 200) {

            /* Ocultamos el texto "Cargando noticias..." */
            if (loading) loading.style.display = 'none';

            /* JSON.parse convierte el texto JSON en array de objetos JS */
            var noticias = JSON.parse(xhr.responseText);

            /* Recorremos el array y creamos una tarjeta por noticia */
            noticias.forEach(function (noticia) {
                var card = document.createElement('article');
                card.classList.add('noticia-card');
                card.innerHTML =
                    '<span>' + (noticia.autor || 'CubiertasChueca') + '</span>' +
                    '<h3>' + noticia.titulo + '</h3>' +
                    '<p>' + noticia.descripcion + '</p>' +
                    '<p class="fecha">📅 ' + noticia.fecha + '</p>';
                contenedor.appendChild(card);
            });

        } else if (xhr.readyState === 4) {
            /* Error de conexión o la BD no está disponible */
            if (loading) loading.textContent = 'No se pudieron cargar las noticias.';
        }
    };

    /* ── PASO 4: Lanzar la petición ── */
    xhr.send();
});
