/* ============================================================
   main.js — Idéntico al proyecto JS Avanzado original
   - Año dinámico en el footer
   - Marca el enlace activo en la navbar
   ============================================================ */
document.addEventListener('DOMContentLoaded', function () {

    /* Año dinámico en el footer */
    var spanAno = document.getElementById('footer-year');
    if (spanAno) spanAno.textContent = new Date().getFullYear();

    /* Marcar enlace activo en la navbar según la URL actual */
    var links = document.querySelectorAll('.menu li a');
    links.forEach(function (link) {
        if (link.href === window.location.href) {
            link.classList.add('activo');
        }
    });

    /* Barra de fuerza de contraseña (registro) */
    var campoPass   = document.getElementById('password');
    var barraFuerza = document.getElementById('barra-fuerza');
    if (campoPass && barraFuerza) {
        campoPass.addEventListener('input', function () {
            var v = this.value;
            var f = 0;
            if (v.length >= 6)       f++;
            if (v.length >= 10)      f++;
            if (/[A-Z]/.test(v))     f++;
            if (/[0-9]/.test(v))     f++;
            if (/[^A-Za-z0-9]/.test(v)) f++;
            var cols = ['#dc3545','#fd7e14','#ffc107','#28a745','#20c997'];
            barraFuerza.style.width      = ((f/5)*100) + '%';
            barraFuerza.style.background = cols[Math.min(f,4)];
        });
    }

    /* Validación visual en tiempo real del email */
    var campoEmail = document.getElementById('email');
    if (campoEmail) {
        campoEmail.addEventListener('input', function () {
            var regex = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
            if (this.value.length === 0)  this.style.borderColor = '#ddd';
            else if (regex.test(this.value)) this.style.borderColor = '#28a745';
            else                          this.style.borderColor = '#dc3545';
        });
    }

    /* Alertas de éxito: desaparecen solas tras 4 segundos */
    document.querySelectorAll('.alert-php-success').forEach(function (el) {
        setTimeout(function () {
            el.style.transition = 'opacity .4s';
            el.style.opacity = '0';
            setTimeout(function () { el.style.display = 'none'; }, 400);
        }, 4000);
    });

    /* Buscador en tiempo real en tablas de administración */
    var buscador = document.getElementById('buscador-tabla');
    var tbody    = document.querySelector('table tbody');
    if (buscador && tbody) {
        buscador.addEventListener('input', function () {
            var q = this.value.toLowerCase();
            tbody.querySelectorAll('tr').forEach(function (tr) {
                tr.style.display = tr.textContent.toLowerCase().includes(q) ? '' : 'none';
            });
        });
    }
});
