<?php
session_start(); require_once 'config/db.php';
if (!isset($_SESSION['rol'])) { header('Location: login.php'); exit; }
$idUser = $_SESSION['idUser']; $errores = []; $ok_datos = false; $ok_pass = false;

$st = $pdo->prepare("SELECT ud.*,ul.usuario,ul.rol FROM users_data ud JOIN users_login ul ON ud.idUser=ul.idUser WHERE ud.idUser=?");
$st->execute([$idUser]); $user = $st->fetch();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    if ($action === 'datos') {
        $nombre=trim($_POST['nombre']??'');
        $apellidos=trim($_POST['apellidos']??''); $email=trim($_POST['email']??'');
        $telefono=trim($_POST['telefono']??''); $fnac=trim($_POST['fecha_nacimiento']??'');
        $dir=trim($_POST['direccion']??''); $sexo=trim($_POST['sexo']??'');
        if (empty($nombre))    $errores[]='Nombre obligatorio.';
        if (empty($apellidos)) $errores[]='Apellidos obligatorios.';
        if (!filter_var($email,FILTER_VALIDATE_EMAIL)) $errores[]='Email no válido.';
        if (empty($telefono))  $errores[]='Teléfono obligatorio.';
        if (empty($fnac))      $errores[]='Fecha de nacimiento obligatoria.';
        if (empty($sexo))      $errores[]='Sexo obligatorio.';
        if (empty($errores)) {
            $s2=$pdo->prepare("SELECT idUser FROM users_data WHERE email=? AND idUser!=?");
            $s2->execute([$email,$idUser]);
            if($s2->fetch()) $errores[]='Email en uso por otra cuenta.';
        }
        if (empty($errores)) {
            $pdo->prepare("UPDATE users_data SET nombre=?,apellidos=?,email=?,telefono=?,fecha_nacimiento=?,direccion=?,sexo=? WHERE idUser=?")
                ->execute([$nombre,$apellidos,$email,$telefono,$fnac,$dir,$sexo,$idUser]);
            $ok_datos=true; $st->execute([$idUser]); $user=$st->fetch();
        }
    }
    if ($action === 'password') {
        $actual=$_POST['password_actual']??''; $nueva=$_POST['password_nueva']??''; $conf=$_POST['password_confirmar']??'';
        $s2=$pdo->prepare("SELECT password FROM users_login WHERE idUser=?"); $s2->execute([$idUser]);
        $hash=$s2->fetchColumn();
        if (!password_verify($actual,$hash)) $errores[]='La contraseña actual no es correcta.';
        if (strlen($nueva)<6)               $errores[]='La nueva contraseña debe tener al menos 6 caracteres.';
        if ($nueva!==$conf)                 $errores[]='Las nuevas contraseñas no coinciden.';
        if (empty($errores)) {
            $pdo->prepare("UPDATE users_login SET password=? WHERE idUser=?")
                ->execute([password_hash($nueva,PASSWORD_DEFAULT),$idUser]);
            $ok_pass=true;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Mi perfil | CubiertasChueca</title>
  <link href="https://fonts.googleapis.com/css2?family=Work+Sans:wght@300;400;600&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="css/style.css">
</head>
<body>
<?php include 'includes/navbar.php'; ?>
<main>
<div class="container-sm" style="padding-top:20px">

  <div class="php-card" style="padding:0;overflow:hidden;margin-bottom:20px">
    <div class="perfil-header">
      <div class="perfil-avatar">👤</div>
      <div>
        <h2 style="margin:0;font-size:20px"><?= htmlspecialchars($user['nombre'].' '.$user['apellidos']) ?></h2>
        <p style="margin:4px 0 0;opacity:.8;font-size:14px">@<?= htmlspecialchars($user['usuario']) ?>
          &nbsp;<span class="badge-php badge-<?= $user['rol'] ?>"><?= $user['rol'] ?></span></p>
      </div>
    </div>
  </div>

  <?php if (!empty($errores)): ?><div class="alert-php alert-php-danger"><ul style="margin:0;padding-left:20px"><?php foreach($errores as $e): ?><li><?= htmlspecialchars($e) ?></li><?php endforeach; ?></ul></div><?php endif; ?>
  <?php if ($ok_datos): ?><div class="alert-php alert-php-success">✅ Datos actualizados correctamente.</div><?php endif; ?>
  <?php if ($ok_pass):  ?><div class="alert-php alert-php-success">✅ Contraseña cambiada correctamente.</div><?php endif; ?>

  <div class="php-card">
    <h2>Datos personales</h2>
    <form method="POST" action="perfil.php">
      <input type="hidden" name="action" value="datos">
      <div class="php-form-row">
        <div class="php-form-group"><label>Nombre *</label><input type="text" name="nombre" value="<?= htmlspecialchars($user['nombre']) ?>" required></div>
        <div class="php-form-group"><label>Apellidos *</label><input type="text" name="apellidos" value="<?= htmlspecialchars($user['apellidos']) ?>" required></div>
      </div>
      <div class="php-form-group"><label>Nombre de usuario</label>
        <input type="text" value="<?= htmlspecialchars($user['usuario']) ?>" disabled style="background:#f5f5f5;color:#888">
        <p class="php-form-note">🔒 No se puede modificar.</p></div>
      <div class="php-form-group"><label>Email *</label><input type="email" name="email" value="<?= htmlspecialchars($user['email']) ?>" required></div>
      <div class="php-form-row">
        <div class="php-form-group"><label>Teléfono *</label><input type="tel" name="telefono" value="<?= htmlspecialchars($user['telefono']) ?>" required></div>
        <div class="php-form-group"><label>Fecha nacimiento *</label><input type="date" name="fecha_nacimiento" value="<?= htmlspecialchars($user['fecha_nacimiento']) ?>" required></div>
      </div>
      <div class="php-form-row">
        <div class="php-form-group"><label>Sexo *</label>
          <select name="sexo" required>
            <option value="Hombre" <?= $user['sexo']==='Hombre'?'selected':'' ?>>Hombre</option>
            <option value="Mujer"  <?= $user['sexo']==='Mujer' ?'selected':'' ?>>Mujer</option>
            <option value="Otro"   <?= $user['sexo']==='Otro'  ?'selected':'' ?>>Otro</option>
          </select></div>
        <div class="php-form-group"><label>Dirección</label><input type="text" name="direccion" value="<?= htmlspecialchars($user['direccion']??'') ?>"></div>
      </div>
      <button type="submit" class="btn-enviar">💾 Guardar cambios</button>
    </form>
  </div>

  <div class="php-card">
    <h2>Cambiar contraseña</h2>
    <form method="POST" action="perfil.php">
      <input type="hidden" name="action" value="password">
      <div class="php-form-group"><label>Contraseña actual *</label><input type="password" name="password_actual" required></div>
      <div class="php-form-row">
        <div class="php-form-group"><label>Nueva contraseña *</label><input type="password" name="password_nueva" required minlength="6"></div>
        <div class="php-form-group"><label>Confirmar nueva *</label><input type="password" name="password_confirmar" required></div>
      </div>
      <p class="php-form-note mb-2">La contraseña nunca se muestra, solo se puede cambiar. Mínimo 6 caracteres.</p>
      <button type="submit" class="btn-reset" style="border-color:#1a1a2e;color:#1a1a2e">🔑 Cambiar contraseña</button>
    </form>
  </div>
</div>
</main>
<footer><div class="footer-aviso"><p>&copy; <span id="footer-year"></span> CubiertasChueca.</p></div></footer>
<script src="js/main.js"></script>
</body></html>
