<?php
/* ============================================================
   navbar.php — Barra de navegación dinámica
   Mantiene el diseño original del proyecto JS Avanzado.
   Añade los enlaces de sesión según el rol PHP:
   - Sin sesión: Inicio, Galería, Presupuesto, Contacto, Noticias, Login, Registro
   - user: añade Mis citas, Mi perfil, Cerrar sesión
   - admin: añade panel de administración completo
   El prefijo de ruta cambia según si estamos en raíz o en views/
   ============================================================ */
if (session_status() === PHP_SESSION_NONE) session_start();
$rol     = $_SESSION['rol']     ?? null;
$usuario = $_SESSION['usuario'] ?? null;
$current = basename($_SERVER['PHP_SELF']);

/* Detectamos si estamos dentro de views/ para ajustar las rutas */
$en_views = (strpos($_SERVER['PHP_SELF'], '/views/') !== false);
$raiz     = $en_views ? '../' : '';
?>
<header>
  <ul class="menu">
    <li>
      <a href="<?= $raiz ?>index.php">
        <img class="LOGO1" src="<?= $raiz ?>images/roof-svgrepo-com.png" alt="Logo CubiertasChueca" width="40" height="40">
      </a>
    </li>
    <li><a <?php echo $current==='index.php'?' class="activo"':'';?> href="<?= $raiz ?>index.php">Inicio</a></li>
    <li><a <?php echo $current==='galeria.html'||$current==='galeria.php'?' class="activo"':'';?> href="<?= $raiz ?>views/galeria.php">Galería</a></li>
    <li><a <?php echo $current==='presupuesto.html'||$current==='presupuesto.php'?' class="activo"':'';?> href="<?= $raiz ?>views/presupuesto.php">Presupuesto</a></li>
    <li><a <?php echo $current==='contacto.html'||$current==='contacto.php'?' class="activo"':'';?> href="<?= $raiz ?>views/contacto.php">Contacto</a></li>
      <li><a <?php echo (basename($_SERVER['PHP_SELF']) === 'noticias.php') ? 'class="activo"' : ''; ?> href="/CUBIERTAS_PHP/views/noticias.php">Noticias</a></li> 

    <?php if (!$rol): ?>
      <!-- Visitante: mostrar registro y login -->
      <li><a <?php echo $current==='registro.php'?' class="activo"':'';?> href="<?= $raiz ?>registro.php">Registrarse</a></li>
      <li><a <?php echo $current==='login.php'?' class="activo"':'';?> href="<?= $raiz ?>login.php">Iniciar sesión</a></li>

    <?php elseif ($rol === 'user'): ?>
      <!-- Usuario logueado -->
      <li><a <?php echo $current==='citaciones.php'?' class="activo"':'';?> href="<?= $raiz ?>citaciones.php">Mis citas</a></li>
      <li><a <?php echo $current==='perfil.php'?' class="activo"':'';?> href="<?= $raiz ?>perfil.php">Mi perfil</a></li>
      <li><a href="<?= $raiz ?>logout.php">Cerrar sesión</a></li>

    <?php elseif ($rol === 'admin'): ?>
      <!-- Administrador -->
      <li><a <?php echo $current==='usuarios-administracion.php'?' class="activo"':'';?> href="<?= $raiz ?>usuarios-administracion.php">Usuarios</a></li>
      <li><a <?php echo $current==='citas-administracion.php'?' class="activo"':'';?> href="<?= $raiz ?>citas-administracion.php">Citas</a></li>
      <li><a <?php echo $current==='noticias-administracion.php'?' class="activo"':'';?> href="<?= $raiz ?>noticias-administracion.php">Admin noticias</a></li>
      <li><a <?php echo $current==='perfil.php'?' class="activo"':'';?> href="<?= $raiz ?>perfil.php">Mi perfil</a></li>
      <li><a href="<?= $raiz ?>logout.php">Cerrar sesión</a></li>
    <?php endif; ?>
  </ul>
</header>
