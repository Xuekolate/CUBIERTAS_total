<?php
/**
 * ARCHIVO DE CONEXIÓN A LA BASE DE DATOS (PDO)
 *
 * Configuración de credenciales y conexión segura mediante PDO a MariaDB/MySQL en XAMPP.
 */

// 1. CONFIGURACIÓN DE PARÁMETROS
// Usamos '127.0.0.1' en lugar de 'localhost' para forzar a PHP/Windows a utilizar 
// la pila de red TCP/IP. Con 'localhost', Windows intenta usar sockets/pipes locales 
// ignorando a menudo el puerto especificado.
define('DB_HOST', '127.0.0.1');

// Puerto personalizado de MySQL/MariaDB en XAMPP (se utiliza el 3307 para evitar 
// conflictos con otras instancias de MySQL en el puerto estándar 3306, como Workbench).
define('DB_PORT', '3307');

// Nombre exacto de la base de datos importada en phpMyAdmin.
define('DB_NAME', 'cubiertaschueca');

// Credenciales del usuario creado explícitamente en el servidor MySQL de XAMPP.
define('DB_USER', 'adrian');
define('DB_PASS', '1234');

// Ruta absoluta para el directorio de subida de archivos (calculada desde la ubicación de este script).
define('UPLOAD_DIR', __DIR__ . '/../uploads/');


// 2. INICIALIZACIÓN DE LA CONEXIÓN
try {
    // Definición de la cadena DSN (Data Source Name).
    // Incluye de forma explícita el host, puerto, nombre de la BD y la codificación utf8mb4.
    $dsn = 'mysql:host=' . DB_HOST . ';port=' . DB_PORT . ';dbname=' . DB_NAME . ';charset=utf8mb4';

    // Instanciación del objeto PDO con sus opciones de configuración.
    $pdo = new PDO(
        $dsn,
        DB_USER,
        DB_PASS,
        [
            // Configura PDO para que lance excepciones (PDOException) ante cualquier error SQL.
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            
            // Define el modo de lectura por defecto a arrays asociativos ($fila['campo']).
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            
            // Desactiva la emulación de sentencias preparadas para utilizar las nativas del motor de la BD (más seguro).
            PDO::ATTR_EMULATE_PREPARES   => false,
        ]
    );

} catch (PDOException $e) {
    // Captura de errores en caso de fallo de conexión.
    // Muestra el mensaje técnico real del driver de la BD y un aviso informativo.
    die('<p style="color:red;padding:20px;font-family:Arial">Error BD: '
        . htmlspecialchars($e->getMessage())
        . '<br>Comprueba que MySQL está activo en XAMPP y que importaste database.sql</p>');
}
?>