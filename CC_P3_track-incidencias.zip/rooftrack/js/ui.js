/* ============================================================
   ui.js — CubiertasChueca Track
   ============================================================
   Capa de presentación del sistema de incidencias.
   Transforma los datos en HTML visible.
   No guarda datos ni gestiona eventos — eso lo hace app.js.
   ============================================================ */

'use strict';

/* Etiquetas legibles para mostrar al equipo de CubiertasChueca */
var LABEL_ESTADO = {
  nuevo:      'Nuevo',
  en_proceso: 'En proceso',
  resuelto:   'Resuelto',
  cerrado:    'Cerrado'
};

var LABEL_URGENCIA = {
  urgente: '🔴 Urgente',
  alta:    '🟠 Alta',
  media:   '🔵 Media',
  baja:    '🟢 Baja'
};

var LABEL_TIPO = {
  gotera:          'Gotera',
  desprendimiento: 'Desprendimiento',
  filtracion:      'Filtración',
  mantenimiento:   'Mantenimiento',
  otro:            'Otro'
};

/* Referencias al DOM */
var listaContainer = document.getElementById('lista-container');
var listaVacia     = document.getElementById('lista-vacia');
var modal          = document.getElementById('modal-incidencia');
var modalTitulo    = document.getElementById('modal-titulo');
var grupoEstado    = document.getElementById('grupo-estado');
var footerYear     = document.getElementById('footer-year');

/* Año en el footer */
if (footerYear) footerYear.textContent = new Date().getFullYear();

/* ============================================================
   renderLista — Dibuja las tarjetas de incidencias
   ============================================================ */
function renderLista(incidencias) {
  /* Eliminamos las tarjetas anteriores */
  var items = listaContainer.querySelectorAll('.incidencia-card');
  items.forEach(function (el) { el.remove(); });

  if (incidencias.length === 0) {
    listaVacia.style.display = 'block';
    return;
  }

  listaVacia.style.display = 'none';

  incidencias.forEach(function (inc) {
    listaContainer.appendChild(crearTarjeta(inc));
  });
}

/* ============================================================
   crearTarjeta — Genera el HTML de una incidencia
   ============================================================ */
function crearTarjeta(inc) {
  var article = document.createElement('article');
  article.classList.add('incidencia-card');
  article.setAttribute('data-estado',   inc.estado);
  article.setAttribute('data-urgencia', inc.urgencia);
  article.setAttribute('data-id',       inc.id);

  var fecha = new Date(inc.fechaCreacion).toLocaleDateString('es-ES', {
    day: '2-digit', month: 'short', year: 'numeric'
  });

  /* Visita programada — solo si existe */
  var visitaHtml = inc.fechaVisita
    ? '<span class="card-visita">📅 Visita: ' +
        new Date(inc.fechaVisita + 'T00:00:00').toLocaleDateString('es-ES') +
      '</span>'
    : '';

  /* Técnico asignado de CubiertasChueca — solo si existe */
  var tecnicoHtml = inc.tecnico
    ? '<span class="card-tecnico">👷 ' + inc.tecnico + '</span>'
    : '<span class="card-tecnico sin-asignar">Sin asignar</span>';

  article.innerHTML =
    '<header class="card-header">' +
      '<div class="card-header-left">' +
        '<span class="card-ref">' + inc.id + '</span>' +
        '<span class="card-cliente">' + inc.cliente + '</span>' +
      '</div>' +
      '<span class="card-fecha">' + fecha + '</span>' +
    '</header>' +

    '<p class="card-tipo">' +
      '<strong>' + (LABEL_TIPO[inc.tipo] || inc.tipo) + '</strong>' +
      ' — ' + inc.direccion +
    '</p>' +

    '<p class="card-descripcion">' + inc.descripcion + '</p>' +

    '<footer class="card-footer">' +
      '<span class="badge badge-estado-' + inc.estado + '">' +
        (LABEL_ESTADO[inc.estado] || inc.estado) +
      '</span>' +
      '<span class="badge badge-urgencia-' + inc.urgencia + '">' +
        (LABEL_URGENCIA[inc.urgencia] || inc.urgencia) +
      '</span>' +
      tecnicoHtml +
      visitaHtml +
      '<span class="card-acciones">' +
        '<button class="btn-editar-card" data-id="' + inc.id + '" ' +
                'aria-label="Editar incidencia ' + inc.id + '">✏️ Editar</button>' +
        '<button class="btn-eliminar-card" data-id="' + inc.id + '" ' +
                'aria-label="Eliminar incidencia ' + inc.id + '">🗑 Eliminar</button>' +
      '</span>' +
    '</footer>';

  return article;
}

/* ============================================================
   renderEstadisticas — Actualiza los 4 contadores del header
   ============================================================ */
function renderEstadisticas(incidencias) {
  document.getElementById('stat-total').textContent =
    incidencias.length;
  document.getElementById('stat-activas').textContent =
    incidencias.filter(function (i) { return i.estado === 'en_proceso'; }).length;
  document.getElementById('stat-urgentes').textContent =
    incidencias.filter(function (i) { return i.urgencia === 'urgente'; }).length;
  document.getElementById('stat-resueltas').textContent =
    incidencias.filter(function (i) { return i.estado === 'resuelto'; }).length;
}

/* ============================================================
   abrirModalNueva — Abre el modal vacío para crear
   ============================================================ */
function abrirModalNueva() {
  limpiarFormulario();
  modalTitulo.textContent   = 'Nueva incidencia';
  grupoEstado.style.display = 'none';
  document.getElementById('btn-guardar-modal').textContent = 'Crear incidencia';
  modal.showModal();
}

/* ============================================================
   abrirModalEditar — Abre el modal pre-rellenado para editar
   ============================================================ */
function abrirModalEditar(inc) {
  limpiarFormulario();
  modalTitulo.textContent   = 'Editar — ' + inc.id;
  grupoEstado.style.display = 'block';

  document.getElementById('inc-id').value           = inc.id;
  document.getElementById('inc-cliente').value      = inc.cliente     || '';
  document.getElementById('inc-telefono').value     = inc.telefono    || '';
  document.getElementById('inc-direccion').value    = inc.direccion   || '';
  document.getElementById('inc-tipo').value         = inc.tipo        || '';
  document.getElementById('inc-urgencia').value     = inc.urgencia    || '';
  document.getElementById('inc-descripcion').value  = inc.descripcion || '';
  document.getElementById('inc-tecnico').value      = inc.tecnico     || '';
  document.getElementById('inc-fecha-visita').value = inc.fechaVisita || '';
  document.getElementById('inc-estado').value       = inc.estado      || 'nuevo';
  document.getElementById('inc-notas').value        = inc.notas       || '';

  document.getElementById('btn-guardar-modal').textContent = 'Guardar cambios';
  modal.showModal();
}

/* ============================================================
   cerrarModal
   ============================================================ */
function cerrarModal() {
  modal.close();
  limpiarFormulario();
}

/* ============================================================
   leerFormulario — Recoge los valores del formulario del modal
   ============================================================ */
function leerFormulario() {
  return {
    id:          document.getElementById('inc-id').value.trim(),
    cliente:     document.getElementById('inc-cliente').value.trim(),
    telefono:    document.getElementById('inc-telefono').value.trim(),
    direccion:   document.getElementById('inc-direccion').value.trim(),
    tipo:        document.getElementById('inc-tipo').value,
    urgencia:    document.getElementById('inc-urgencia').value,
    descripcion: document.getElementById('inc-descripcion').value.trim(),
    tecnico:     document.getElementById('inc-tecnico').value.trim(),
    fechaVisita: document.getElementById('inc-fecha-visita').value,
    estado:      document.getElementById('inc-estado').value || 'nuevo',
    notas:       document.getElementById('inc-notas').value.trim()
  };
}

/* ============================================================
   limpiarFormulario — Vacía todos los campos del modal
   ============================================================ */
function limpiarFormulario() {
  var campos = [
    'inc-id', 'inc-cliente', 'inc-telefono', 'inc-direccion',
    'inc-tipo', 'inc-urgencia', 'inc-descripcion', 'inc-tecnico',
    'inc-fecha-visita', 'inc-estado', 'inc-notas'
  ];
  campos.forEach(function (id) {
    var el = document.getElementById(id);
    if (el) el.value = '';
  });
  document.querySelectorAll('#modal-incidencia .error').forEach(function (el) {
    el.classList.remove('error');
  });
  document.querySelectorAll('#modal-incidencia .msg-error').forEach(function (el) {
    el.classList.remove('visible');
  });
}

/* Exportamos el módulo */
window.RoofUI = {
  renderLista:        renderLista,
  renderEstadisticas: renderEstadisticas,
  abrirModalNueva:    abrirModalNueva,
  abrirModalEditar:   abrirModalEditar,
  cerrarModal:        cerrarModal,
  leerFormulario:     leerFormulario,
  limpiarFormulario:  limpiarFormulario
};
