/* ============================================================
   db.js — CubiertasChueca Track
   ============================================================
   Capa de datos del sistema de gestión de incidencias de
   CubiertasChueca. Todos los accesos a localStorage pasan
   por este módulo (Patrón Repository).

   La clave en localStorage es 'cc_incidencias' (cc = CubiertasChueca)
   para evitar conflictos con otras aplicaciones en el mismo dominio.
   ============================================================ */

'use strict';

const DB_KEY = 'cc_incidencias'; // CubiertasChueca incidencias

/* ============================================================
   DATOS DE EJEMPLO DE CUBIERTASCHUECA
   Incidencias reales y representativas del trabajo diario
   de la empresa. Se cargan la primera vez que se abre la app.
   ============================================================ */
const INCIDENCIAS_EJEMPLO = [
  {
    id:          'CC-001',
    cliente:     'Comunidad Jardines del Rey',
    telefono:    '915001234',
    direccion:   'Av. de los Robles 14, Alcorcón, Madrid',
    tipo:        'gotera',
    urgencia:    'alta',
    descripcion: 'Gotera en la cumbrera del bloque B. Aparece con lluvia fuerte ' +
                 'desde el temporal de marzo. El presidente de la comunidad ' +
                 'informa de manchas en el techo del ático 4º B.',
    tecnico:     'Manuel García',
    estado:      'en_proceso',
    fechaVisita: '2024-04-10',
    notas:       'Inspeccionado el 03/04. Pendiente de pizarras de repuesto ' +
                 '(calibre 40×20). Proveedor: Pizarras Cupa, pedido realizado.',
    fechaCreacion:      new Date('2024-04-01').toISOString(),
    fechaActualizacion: new Date('2024-04-03').toISOString()
  },
  {
    id:          'CC-002',
    cliente:     'José Martínez Sánchez',
    telefono:    '622334455',
    direccion:   'C/ Pino 7, 2ºB, Leganés, Madrid',
    tipo:        'desprendimiento',
    urgencia:    'urgente',
    descripcion: 'Varias pizarras desprendidas tras el temporal del fin de semana. ' +
                 'Riesgo para viandantes. La propiedad ha colocado cinta de ' +
                 'señalización pero requiere intervención urgente.',
    tecnico:     '',
    estado:      'nuevo',
    fechaVisita: '',
    notas:       '',
    fechaCreacion:      new Date('2024-04-05').toISOString(),
    fechaActualizacion: new Date('2024-04-05').toISOString()
  },
  {
    id:          'CC-003',
    cliente:     'Inmobiliaria Ática 7 S.L.',
    telefono:    '916778899',
    direccion:   'C/ Ática 7, Pozuelo de Alarcón, Madrid',
    tipo:        'filtracion',
    urgencia:    'media',
    descripcion: 'Filtración de agua en el penthouse. Mancha en el techo del salón ' +
                 'principal, zona de 30×40 cm aproximadamente. ' +
                 'La cubierta es de zinc titanio instalada por CubiertasChueca en 2018.',
    tecnico:     'Antonio Chueca',
    estado:      'resuelto',
    fechaVisita: '2024-03-20',
    notas:       'Reparada junta de zinc en babero de chimenea. ' +
                 'Sellado con masilla bituminosa. Garantía 15 años.',
    fechaCreacion:      new Date('2024-03-15').toISOString(),
    fechaActualizacion: new Date('2024-03-22').toISOString()
  },
  {
    id:          'CC-004',
    cliente:     'Colegio San José de Calasanz',
    telefono:    '911223344',
    direccion:   'C/ Maestro Guerrero 8, Madrid',
    tipo:        'mantenimiento',
    urgencia:    'baja',
    descripcion: 'Revisión anual de la cubierta de pizarra. ' +
                 'Limpieza de canalones y comprobación del estado de las ' +
                 'limas y cumbreras. Cubierta instalada en 1998.',
    tecnico:     'Manuel García',
    estado:      'nuevo',
    fechaVisita: '2024-04-20',
    notas:       'Programar para un sábado — el centro está abierto entre semana.',
    fechaCreacion:      new Date('2024-04-08').toISOString(),
    fechaActualizacion: new Date('2024-04-08').toISOString()
  }
];

/* ============================================================
   getAll — Obtener todas las incidencias de CubiertasChueca
   ============================================================ */
function getAll() {
  var raw = localStorage.getItem(DB_KEY);
  if (!raw) return [];
  try {
    return JSON.parse(raw);
  } catch (e) {
    console.error('CubiertasChueca Track — Error al leer datos:', e);
    return [];
  }
}

/* ============================================================
   saveAll — Guardar el array completo (uso interno)
   ============================================================ */
function saveAll(incidencias) {
  localStorage.setItem(DB_KEY, JSON.stringify(incidencias));
}

/* ============================================================
   crear — Registrar una nueva incidencia
   ============================================================
   El ID tiene el prefijo CC- (CubiertasChueca) para identificar
   claramente el origen en documentos y reportes. */
function crear(datos) {
  var incidencias = getAll();
  var ahora       = new Date().toISOString();

  /* Generamos un ID con prefijo CC y timestamp en milisegundos.
     Ejemplo: CC-1712345678901 */
  var nuevaId = 'CC-' + Date.now();

  var nueva = Object.assign({}, datos, {
    id:                 nuevaId,
    estado:             datos.estado || 'nuevo',
    fechaCreacion:      ahora,
    fechaActualizacion: ahora
  });

  incidencias.push(nueva);
  saveAll(incidencias);
  return nueva;
}

/* ============================================================
   getPorId — Buscar una incidencia por su ID
   ============================================================ */
function getPorId(id) {
  var encontrada = getAll().find(function (inc) {
    return inc.id === id;
  });
  return encontrada || null;
}

/* ============================================================
   actualizar — Modificar una incidencia existente
   ============================================================ */
function actualizar(id, cambios) {
  var incidencias = getAll();
  var idx = incidencias.findIndex(function (inc) { return inc.id === id; });

  if (idx === -1) {
    console.warn('CubiertasChueca Track — Incidencia no encontrada:', id);
    return null;
  }

  incidencias[idx] = Object.assign({}, incidencias[idx], cambios, {
    fechaActualizacion: new Date().toISOString()
  });

  saveAll(incidencias);
  return incidencias[idx];
}

/* ============================================================
   eliminar — Borrar una incidencia del registro
   ============================================================ */
function eliminar(id) {
  var incidencias  = getAll();
  var longitudAntes = incidencias.length;
  var nuevas = incidencias.filter(function (inc) { return inc.id !== id; });

  if (nuevas.length === longitudAntes) return false;
  saveAll(nuevas);
  return true;
}

/* ============================================================
   cambiarEstado — Atajo para actualizar solo el estado
   ============================================================ */
function cambiarEstado(id, nuevoEstado) {
  return actualizar(id, { estado: nuevoEstado });
}

/* ============================================================
   inicializar — Cargar los datos de ejemplo de CubiertasChueca
   ============================================================ */
function inicializar() {
  if (getAll().length === 0) {
    saveAll(INCIDENCIAS_EJEMPLO);
    console.log(
      'CubiertasChueca Track — Cargadas ' +
      INCIDENCIAS_EJEMPLO.length + ' incidencias de ejemplo.'
    );
  }
}

/* Exportamos el módulo como objeto global */
window.RoofDB = {
  getAll:        getAll,
  crear:         crear,
  getPorId:      getPorId,
  actualizar:    actualizar,
  eliminar:      eliminar,
  cambiarEstado: cambiarEstado,
  inicializar:   inicializar
};
