/* ============================================================
   app.js — CubiertasChueca Track
   ============================================================
   Controlador principal del sistema de incidencias.
   Conecta la capa de datos (db.js) con la vista (ui.js).
   Gestiona todos los eventos del usuario.
   ============================================================ */

'use strict';

document.addEventListener('DOMContentLoaded', function () {

  /* Cargamos los datos de ejemplo de CubiertasChueca si la app está vacía */
  RoofDB.inicializar();

  /* Primera carga de la vista */
  refrescar();

  /* ============================================================
     refrescar — Función central: lee datos, aplica filtros, pinta
     ============================================================ */
  function refrescar() {
    var todas     = RoofDB.getAll();
    RoofUI.renderEstadisticas(todas);        // Siempre con el total real
    RoofUI.renderLista(aplicarFiltros(todas)); // Con los filtros aplicados
  }

  /* ============================================================
     aplicarFiltros — Filtra el array según los controles activos
     ============================================================ */
  function aplicarFiltros(incidencias) {
    var texto     = document.getElementById('buscar').value.toLowerCase().trim();
    var estado    = document.getElementById('filtro-estado').value;
    var urgencia  = document.getElementById('filtro-urgencia').value;

    return incidencias.filter(function (inc) {
      var coincideTexto = !texto || (
        (inc.cliente     || '').toLowerCase().includes(texto) ||
        (inc.direccion   || '').toLowerCase().includes(texto) ||
        (inc.descripcion || '').toLowerCase().includes(texto) ||
        (inc.id          || '').toLowerCase().includes(texto)
      );
      var coincideEstado   = !estado   || inc.estado   === estado;
      var coincideUrgencia = !urgencia || inc.urgencia === urgencia;
      return coincideTexto && coincideEstado && coincideUrgencia;
    });
  }

  /* ============================================================
     validarFormulario — Valida los campos obligatorios del modal
     ============================================================ */
  function validarFormulario() {
    var reglas = [
      ['inc-cliente',     'err-inc-cliente',
       function (v) { return v.length >= 2; }],
      ['inc-telefono',    'err-inc-telefono',
       function (v) { return /^[0-9]{9}$/.test(v); }],
      ['inc-direccion',   'err-inc-direccion',
       function (v) { return v.length >= 5; }],
      ['inc-tipo',        'err-inc-tipo',
       function (v) { return v !== ''; }],
      ['inc-urgencia',    'err-inc-urgencia',
       function (v) { return v !== ''; }],
      ['inc-descripcion', 'err-inc-descripcion',
       function (v) { return v.length >= 10; }]
    ];

    var esValido = true;

    reglas.forEach(function (regla) {
      var campo = document.getElementById(regla[0]);
      var error = document.getElementById(regla[1]);
      var valor = campo ? campo.value.trim() : '';
      var ok    = regla[2](valor);

      if (campo) campo.classList.toggle('error', !ok);
      if (error) error.classList.toggle('visible', !ok);
      if (!ok) esValido = false;
    });

    return esValido;
  }

  /* ============================================================
     EVENTOS — botones de la cabecera y de los filtros
     ============================================================ */

  /* Botón "Nueva incidencia" */
  document.getElementById('btn-nueva').addEventListener('click', function () {
    RoofUI.abrirModalNueva();
  });

  /* Botón X del modal */
  document.getElementById('btn-cerrar-modal').addEventListener('click', function () {
    RoofUI.cerrarModal();
  });

  /* Botón Cancelar del modal */
  document.getElementById('btn-cancelar-modal').addEventListener('click', function () {
    RoofUI.cerrarModal();
  });

  /* Cerrar el modal haciendo clic en el fondo oscuro (backdrop) */
  document.getElementById('modal-incidencia').addEventListener('click', function (e) {
    var rect = this.getBoundingClientRect();
    if (
      e.clientX < rect.left  || e.clientX > rect.right ||
      e.clientY < rect.top   || e.clientY > rect.bottom
    ) {
      RoofUI.cerrarModal();
    }
  });

  /* Botón Guardar del modal — crea o edita según haya ID */
  document.getElementById('btn-guardar-modal').addEventListener('click', function () {
    if (!validarFormulario()) return;

    var datos = RoofUI.leerFormulario();

    if (datos.id) {
      /* EDITAR: hay un ID — actualizamos la incidencia existente */
      var id = datos.id;
      delete datos.id;
      RoofDB.actualizar(id, datos);
    } else {
      /* CREAR: no hay ID — registramos una nueva incidencia */
      RoofDB.crear(datos);
    }

    RoofUI.cerrarModal();
    refrescar();
  });

  /* ============================================================
     EVENT DELEGATION — botones de editar y eliminar de las tarjetas
     ============================================================
     Las tarjetas se generan dinámicamente por ui.js.
     En lugar de añadir un listener a cada botón (que cambian
     cada vez que se regenera la lista), escuchamos en el contenedor
     padre y filtramos el clic con e.target.closest(). */
  document.getElementById('lista-container').addEventListener('click', function (e) {

    /* ¿Clic en el botón Editar? */
    var btnEditar = e.target.closest('.btn-editar-card');
    if (btnEditar) {
      var inc = RoofDB.getPorId(btnEditar.getAttribute('data-id'));
      if (inc) RoofUI.abrirModalEditar(inc);
      return;
    }

    /* ¿Clic en el botón Eliminar? */
    var btnEliminar = e.target.closest('.btn-eliminar-card');
    if (btnEliminar) {
      var id = btnEliminar.getAttribute('data-id');
      if (confirm(
        '¿Eliminar esta incidencia de CubiertasChueca?\n' +
        'Esta acción no se puede deshacer.'
      )) {
        RoofDB.eliminar(id);
        refrescar();
      }
    }
  });

  /* Filtros en tiempo real */
  document.getElementById('buscar').addEventListener('input', refrescar);
  document.getElementById('filtro-estado').addEventListener('change', refrescar);
  document.getElementById('filtro-urgencia').addEventListener('change', refrescar);

  /* Botón Limpiar filtros */
  document.getElementById('btn-limpiar-filtros').addEventListener('click', function () {
    document.getElementById('buscar').value           = '';
    document.getElementById('filtro-estado').value   = '';
    document.getElementById('filtro-urgencia').value = '';
    refrescar();
  });

}); /* Fin DOMContentLoaded */
