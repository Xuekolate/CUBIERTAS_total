# CubiertasChueca Track — Sistema de Gestión de Incidencias

Herramienta interna para el equipo técnico de CubiertasChueca.
Permite gestionar todas las incidencias y reparaciones de cubiertas
reportadas por los clientes.

## Funcionalidades
- CRUD completo de incidencias con referencia CC-XXXXXXXX
- Filtro por estado, urgencia y búsqueda en tiempo real
- Modal nativo HTML5 (<dialog>) sin librerías externas
- Estadísticas en tiempo real del equipo
- Diseño mobile-first para uso en obra desde el móvil
- Datos de ejemplo reales del sector

## Stack
HTML5 · CSS3 Grid mobile-first · JavaScript ES6 · localStorage

## Instalación
Abrir index.html con Live Server. No requiere servidor.
