# CubiertasChueca Admin — Panel de Gestión

Panel de administración para CubiertasChueca con CRUD completo
en PHP y MySQL para gestión de clientes, presupuestos e incidencias.

## Instalación
1. Instala XAMPP (xampp.org)
2. Copia la carpeta en xampp/htdocs/cubiertaschueca-admin/
3. phpMyAdmin → crear BD "cubiertaschueca" → importar sql/cubiertaschueca_admin.sql
4. Acceder a http://localhost/cubiertaschueca-admin/

## Stack
PHP 8 · MySQL 8 · PDO · HTML5 · CSS3 · JavaScript

## Seguridad
- Prepared statements PDO → prevención SQL Injection
- htmlspecialchars() en salidas → prevención XSS
- Patrón Post/Redirect/Get → sin duplicados en formularios
