<?php
/* ============================================================
   config/db.php — CubiertasChueca Admin
   ============================================================
   Este archivo hace UNA sola cosa: conectar con MySQL usando PDO.

   PDO (PHP Data Objects) es la forma moderna y segura de
   conectar PHP con bases de datos. Ventajas sobre mysql_* o mysqli_*:
     - Misma API para MySQL, PostgreSQL, SQLite...
     - Prepared statements reales (prevención de SQL Injection)
     - Manejo de errores con excepciones (try/catch)

   CÓMO USARLO EN CUALQUIER PÁGINA PHP:
     require_once '../config/db.php';    // o la ruta correcta
     $pdo = conectarBD();
     $stmt = $pdo->prepare("SELECT ...");
     $stmt->execute([...]);
     $filas = $stmt->fetchAll();
   ============================================================ */

/* ============================================================
   CONFIGURACIÓN DE LA BASE DE DATOS
   ============================================================
   IMPORTANTE: en producción NUNCA pongas estas credenciales
   directamente en el código. Usa variables de entorno o un
   archivo .env fuera del directorio público del servidor.
   Para desarrollo local con XAMPP, esto es suficiente. */

define('DB_HOST',    'localhost');  // El servidor de MySQL (en XAMPP siempre es localhost)
define('DB_NAME',    'cubiertaschueca'); // El nombre de la BD que creaste en phpMyAdmin
define('DB_USER',    'root');      // Usuario de MySQL (en XAMPP por defecto es 'root')
define('DB_PASS',    '');          // Contraseña de MySQL (en XAMPP por defecto está vacía)
define('DB_CHARSET', 'utf8mb4');   // Codificación: utf8mb4 soporta todos los caracteres


/* ============================================================
   FUNCIÓN: conectarBD()
   ============================================================
   Crea y devuelve una conexión PDO configurada correctamente.
   Si la conexión falla, lanza una excepción PDOException.

   Por qué una función y no una variable global:
   - Más limpio: cada página pide la conexión solo cuando la necesita
   - Si una página no usa la BD, no se conecta (mejor rendimiento)
   - Más fácil de testear y de cambiar en el futuro */
function conectarBD(): PDO
{
    /* DSN (Data Source Name): cadena que describe cómo conectarse.
       Formato: "driver:host=HOST;dbname=NOMBRE;charset=CHARSET"
       sprintf() es como printf pero devuelve un string en lugar de imprimirlo */
    $dsn = sprintf(
        'mysql:host=%s;dbname=%s;charset=%s',
        DB_HOST,
        DB_NAME,
        DB_CHARSET
    );

    /* Opciones de configuración de PDO */
    $opciones = [
        /* ERRMODE_EXCEPTION: si hay un error de SQL, lanza una excepción.
           Sin esto, los errores fallan silenciosamente (muy difícil de debuguear). */
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,

        /* FETCH_ASSOC: los resultados se devuelven como arrays asociativos.
           Ej: $fila['nombre'] en vez de $fila[0]
           Más legible y menos propenso a errores. */
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,

        /* EMULATE_PREPARES = false: usa prepared statements REALES del servidor MySQL.
           Con true, PDO los simula en PHP (menos seguro).
           Con false, el servidor MySQL hace la separación entre código y datos
           antes de ejecutar la consulta. Esto es lo que previene SQL Injection. */
        PDO::ATTR_EMULATE_PREPARES => false,
    ];

    /* Intentamos crear la conexión.
       Si falla (BD no existe, credenciales incorrectas, servidor caído),
       PDO lanza una PDOException que debemos capturar donde llamemos a esta función. */
    return new PDO($dsn, DB_USER, DB_PASS, $opciones);
}
