<?php
/* ============================================================
   index.php — CubiertasChueca Admin
   Punto de entrada del panel de gestión de CubiertasChueca.
   En el Proyecto 5 (con login) aquí se comprobará la sesión.
   ============================================================ */
header('Location: clientes/listar.php');
exit;
