-- ============================================================
-- roofadmin.sql — RoofAdmin
-- ============================================================
-- INSTRUCCIONES:
--   1. Abre phpMyAdmin (http://localhost/phpmyadmin)
--   2. Haz clic en "Nuevo" para crear una base de datos
--   3. Ponle el nombre: roofadmin
--   4. Selecciona la BD recién creada
--   5. Ve a la pestaña "SQL"
--   6. Pega TODO este contenido y pulsa "Ejecutar"
-- ============================================================

-- Seleccionamos la BD que acabamos de crear
USE roofadmin;

-- ============================================================
-- TABLA: clientes
-- Guarda los datos de contacto de cada cliente.
-- Es la tabla principal — presupuestos e incidencias la referencian.
-- ============================================================
CREATE TABLE IF NOT EXISTS clientes (
  id          INT UNSIGNED    NOT NULL AUTO_INCREMENT,
  -- AUTO_INCREMENT: MySQL asigna el número automáticamente (1, 2, 3...)

  nombre      VARCHAR(60)     NOT NULL,
  -- VARCHAR(60): texto variable, máximo 60 caracteres. NOT NULL: obligatorio.

  empresa     VARCHAR(80)     DEFAULT NULL,
  -- DEFAULT NULL: es opcional. Si no se introduce, se guarda NULL.

  email       VARCHAR(100)    NOT NULL,
  telefono    VARCHAR(15)     NOT NULL,
  direccion   TEXT            NOT NULL,
  -- TEXT: para textos largos sin límite fijo (hasta 65.535 caracteres)

  notas       TEXT            DEFAULT NULL,

  creado_en   DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
  -- CURRENT_TIMESTAMP: MySQL pone la fecha y hora automáticamente al insertar

  PRIMARY KEY (id),
  -- PRIMARY KEY: identificador único de cada fila. No puede repetirse ni ser NULL.

  UNIQUE KEY uq_clientes_email (email)
  -- UNIQUE: garantiza que no haya dos clientes con el mismo email.
  -- MySQL crea un índice automáticamente en columnas UNIQUE.
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;
-- InnoDB: motor que soporta transacciones y claves foráneas (FK).
-- utf8mb4: soporta todos los caracteres Unicode, incluidos emojis.
-- spanish_ci: ordenación y comparación insensible a mayúsculas en español (ñ, tildes).


-- ============================================================
-- TABLA: tipos_cubierta (catálogo / tabla de referencia)
-- Evitamos repetir "Pizarra natural — 55 €/m²" en cada presupuesto.
-- En su lugar guardamos un código y la tabla presupuestos solo
-- almacena el tipo_cubierta_id. Esto es NORMALIZACIÓN de datos.
-- ============================================================
CREATE TABLE IF NOT EXISTS tipos_cubierta (
  id          TINYINT UNSIGNED NOT NULL AUTO_INCREMENT,
  -- TINYINT: entero pequeño (0-255). Suficiente para un catálogo.

  codigo      VARCHAR(20)      NOT NULL,
  nombre      VARCHAR(80)      NOT NULL,
  precio_m2   DECIMAL(8, 2)    NOT NULL,
  -- DECIMAL(8,2): número exacto con hasta 8 dígitos y 2 decimales.
  -- Para importes SIEMPRE usa DECIMAL, nunca FLOAT (FLOAT tiene errores de redondeo).

  PRIMARY KEY (id),
  UNIQUE KEY uq_tipos_codigo (codigo)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

-- Insertamos los tipos disponibles (datos de referencia)
INSERT INTO tipos_cubierta (codigo, nombre, precio_m2) VALUES
  ('pizarra', 'Pizarra natural',    55.00),
  ('zinc',    'Zinc titanio',       82.00),
  ('teja',    'Teja cerámica',      48.00),
  ('cobre',   'Cobre',              96.00),
  ('imperm',  'Impermeabilización', 32.00);


-- ============================================================
-- TABLA: presupuestos
-- Cada fila es un presupuesto emitido.
-- Se relaciona con clientes (cliente_id) y tipos_cubierta (tipo_cubierta_id).
-- ============================================================
CREATE TABLE IF NOT EXISTS presupuestos (
  id               INT UNSIGNED    NOT NULL AUTO_INCREMENT,
  referencia       VARCHAR(20)     NOT NULL,
  -- referencia: código legible (ej: "RC-2024-001") que se muestra al cliente

  cliente_id       INT UNSIGNED    NOT NULL,
  -- Clave foránea → referencia a clientes.id

  tipo_cubierta_id TINYINT UNSIGNED NOT NULL,
  -- Clave foránea → referencia a tipos_cubierta.id

  m2_superficie    DECIMAL(8, 2)   NOT NULL,
  pendiente_grados TINYINT UNSIGNED NOT NULL DEFAULT 0,
  extras_json      TEXT            DEFAULT NULL,
  -- extras_json: guardamos los extras como JSON porque son variables.
  -- No vale la pena crear una tabla separada para este caso sencillo.
  -- Ejemplo: '["canalon","lucernario"]'

  base_imponible   DECIMAL(10, 2)  NOT NULL,
  iva              DECIMAL(10, 2)  NOT NULL,
  total            DECIMAL(10, 2)  NOT NULL,

  estado           ENUM('borrador','enviado','aceptado','rechazado') NOT NULL DEFAULT 'borrador',
  -- ENUM: solo permite estos valores exactos. Más seguro que VARCHAR para campos fijos.

  validez_dias     TINYINT UNSIGNED NOT NULL DEFAULT 30,
  notas            TEXT            DEFAULT NULL,

  creado_en        DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
  actualizado_en   DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP
                   ON UPDATE CURRENT_TIMESTAMP,
  -- ON UPDATE CURRENT_TIMESTAMP: MySQL actualiza automáticamente esta columna
  -- cada vez que se modifica la fila. Muy útil para auditoría.

  PRIMARY KEY (id),
  UNIQUE KEY uq_presup_referencia (referencia),

  -- FOREIGN KEY (clave foránea): garantiza integridad referencial.
  -- Si intentas insertar un presupuesto con cliente_id=99 y no existe
  -- ningún cliente con id=99, MySQL rechaza la operación.
  CONSTRAINT fk_presup_cliente
    FOREIGN KEY (cliente_id) REFERENCES clientes(id)
    ON DELETE RESTRICT,
  -- ON DELETE RESTRICT: no permite borrar un cliente que tiene presupuestos.

  CONSTRAINT fk_presup_tipo
    FOREIGN KEY (tipo_cubierta_id) REFERENCES tipos_cubierta(id)
    ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;


-- ============================================================
-- TABLA: incidencias
-- Cada fila es una incidencia o reparación reportada por un cliente.
-- ============================================================
CREATE TABLE IF NOT EXISTS incidencias (
  id              INT UNSIGNED    NOT NULL AUTO_INCREMENT,

  cliente_id      INT UNSIGNED    NOT NULL,
  presupuesto_id  INT UNSIGNED    DEFAULT NULL,
  -- presupuesto_id es opcional: una incidencia puede o no estar
  -- asociada a un presupuesto previo.

  tipo            ENUM('gotera','desprendimiento','filtracion','mantenimiento','otro')
                  NOT NULL,
  urgencia        ENUM('baja','media','alta','urgente')
                  NOT NULL DEFAULT 'media',
  descripcion     TEXT            NOT NULL,
  tecnico         VARCHAR(60)     DEFAULT NULL,
  estado          ENUM('nuevo','en_proceso','resuelto','cerrado')
                  NOT NULL DEFAULT 'nuevo',
  fecha_visita    DATE            DEFAULT NULL,
  -- DATE: solo la fecha, sin hora (YYYY-MM-DD). Diferente de DATETIME.
  notas           TEXT            DEFAULT NULL,

  creado_en       DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
  actualizado_en  DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP
                  ON UPDATE CURRENT_TIMESTAMP,

  PRIMARY KEY (id),

  CONSTRAINT fk_incid_cliente
    FOREIGN KEY (cliente_id) REFERENCES clientes(id)
    ON DELETE RESTRICT,

  CONSTRAINT fk_incid_presup
    FOREIGN KEY (presupuesto_id) REFERENCES presupuestos(id)
    ON DELETE SET NULL
    -- ON DELETE SET NULL: si se borra el presupuesto asociado,
    -- el presupuesto_id de la incidencia se pone a NULL (no se borra la incidencia).
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;


-- ============================================================
-- ÍNDICES — mejoran la velocidad de las búsquedas frecuentes
-- ============================================================
-- Sin índice: MySQL revisa TODAS las filas (full table scan).
-- Con índice: MySQL va directo a las filas relevantes.
-- Coste: espacio en disco e INSERT/UPDATE ligeramente más lentos.
-- Se crean en columnas que aparecen en WHERE, JOIN y ORDER BY.

CREATE INDEX idx_presup_estado    ON presupuestos(estado);
CREATE INDEX idx_presup_cliente   ON presupuestos(cliente_id);
CREATE INDEX idx_incid_estado     ON incidencias(estado);
CREATE INDEX idx_incid_cliente    ON incidencias(cliente_id);
CREATE INDEX idx_incid_urgencia   ON incidencias(urgencia);


-- ============================================================
-- DATOS DE EJEMPLO — para poder probar la aplicación
-- ============================================================

-- Insertamos 3 clientes de ejemplo
INSERT INTO clientes (nombre, empresa, email, telefono, direccion, notas) VALUES
  ('Antonio García López',
   'Comunidad Jardines del Rey',
   'antonio@jardinesdelrey.es',
   '915001234',
   'Av. de los Robles 14, Alcorcón, 28921',
   'Comunidad de 48 viviendas. Portero: Luis, ext. 101.'),

  ('María Sánchez Ruiz',
   NULL,
   'maria.sanchez@gmail.com',
   '622334455',
   'C/ Pino 7, 2ºB, Leganés, 28911',
   'Vivienda unifamiliar. Acceso por puerta lateral.'),

  ('Inmobiliaria Ática 7 S.L.',
   'Inmobiliaria Ática 7',
   'obras@atica7.es',
   '916778899',
   'C/ Ática 7, Pozuelo de Alarcón, 28223',
   'Edificio de oficinas. Contacto: Javier Moreno.');


-- Insertamos 2 presupuestos de ejemplo
INSERT INTO presupuestos
  (referencia, cliente_id, tipo_cubierta_id, m2_superficie, pendiente_grados,
   extras_json, base_imponible, iva, total, estado, notas)
VALUES
  ('RC-2024-001', 1, 1, 320.00, 30,
   '["canalon","aislamiento"]',
   19360.00, 4065.60, 23425.60, 'enviado',
   'Cubierta principal bloque A. Pendiente de aceptación.'),

  ('RC-2024-002', 2, 3, 85.00, 25,
   '[]',
   4080.00, 856.80, 4936.80, 'aceptado',
   'Tejado de vivienda unifamiliar. Obra programada para mayo.');


-- Insertamos 2 incidencias de ejemplo
INSERT INTO incidencias
  (cliente_id, presupuesto_id, tipo, urgencia, descripcion, tecnico, estado, fecha_visita, notas)
VALUES
  (1, NULL, 'gotera', 'alta',
   'Gotera en la cumbrera del bloque B. Aparece con lluvia fuerte desde el temporal de marzo.',
   'Manuel García', 'en_proceso', '2024-04-10',
   'Inspeccionado el 03/04. Pendiente de pizarras de repuesto.'),

  (2, 2, 'desprendimiento', 'urgente',
   'Varias pizarras desprendidas tras el temporal. Riesgo para viandantes.',
   NULL, 'nuevo', NULL, '');
