<?php
/* ============================================================
   clientes/editar.php — CubiertasChueca Admin
   ============================================================
   UPDATE — Carga los datos actuales del cliente (GET)
            y guarda los cambios en la BD (POST).

   URL esperada: editar.php?id=3
   $_GET['id'] contiene el ID del cliente a editar.

   DIFERENCIA CON crear.php:
     - Primero hacemos un SELECT para cargar los datos actuales
     - El formulario se pre-rellena con esos datos
     - Al enviar, hacemos un UPDATE (no INSERT)
   ============================================================ */

$tituloPagina = 'Editar cliente';
require_once '../config/db.php';
require_once '../includes/header.php';

/* ============================================================
   OBTENER EL ID DE LA URL
   ============================================================ */

/* intval() convierte el valor a entero y elimina cualquier
   carácter no numérico. Es la sanitización básica para IDs.
   Si id=abc, intval devuelve 0. */
$id = intval($_GET['id'] ?? 0);

/* Si no hay ID válido, no podemos hacer nada → volvemos a la lista */
if ($id <= 0) {
    $_SESSION['error'] = 'Cliente no válido.';
    header('Location: listar.php');
    exit;
}

$errores = [];
$datos   = [];

/* ============================================================
   CARGAR LOS DATOS ACTUALES DEL CLIENTE (siempre, en GET y POST)
   ============================================================ */
try {
    $pdo = conectarBD();

    /* Buscamos el cliente por su ID.
       LIMIT 1: aunque id es PRIMARY KEY (único), es buena práctica
       añadir LIMIT 1 para comunicar la intención claramente. */
    $stmt = $pdo->prepare(
        "SELECT id, nombre, empresa, email, telefono, direccion, notas
         FROM clientes
         WHERE id = :id
         LIMIT 1"
    );
    $stmt->execute([':id' => $id]);
    $clienteActual = $stmt->fetch();
    /* fetch() (sin All) devuelve solo la primera fila, o false si no hay resultados */

    /* Si no existe ese cliente, redirigimos */
    if (!$clienteActual) {
        $_SESSION['error'] = 'No se encontró el cliente con ID ' . $id . '.';
        header('Location: listar.php');
        exit;
    }

    /* La primera vez que se carga la página (GET), $datos viene del SELECT.
       Si hay un POST con errores, $datos viene del formulario (para no
       perder los cambios que el usuario hizo). */
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        $datos = $clienteActual; // Pre-rellenamos con los datos actuales de la BD
    }

} catch (PDOException $e) {
    error_log('CubiertasChueca Admin/editar.php SELECT: ' . $e->getMessage());
    $_SESSION['error'] = 'Error al cargar el cliente.';
    header('Location: listar.php');
    exit;
}

/* ============================================================
   PROCESAMIENTO DEL FORMULARIO (solo en POST)
   ============================================================ */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    /* Recogemos los datos nuevos del formulario */
    $datos['nombre']    = trim($_POST['nombre']    ?? '');
    $datos['empresa']   = trim($_POST['empresa']   ?? '');
    $datos['email']     = trim($_POST['email']     ?? '');
    $datos['telefono']  = trim($_POST['telefono']  ?? '');
    $datos['direccion'] = trim($_POST['direccion'] ?? '');
    $datos['notas']     = trim($_POST['notas']     ?? '');

    /* Las mismas validaciones que en crear.php */
    if (strlen($datos['nombre']) < 2 || strlen($datos['nombre']) > 60) {
        $errores['nombre'] = 'El nombre debe tener entre 2 y 60 caracteres.';
    }
    if (!filter_var($datos['email'], FILTER_VALIDATE_EMAIL)) {
        $errores['email'] = 'Introduce un correo electrónico válido.';
    }
    if (!preg_match('/^[0-9]{9}$/', $datos['telefono'])) {
        $errores['telefono'] = 'El teléfono debe tener exactamente 9 dígitos.';
    }
    if (strlen($datos['direccion']) < 5) {
        $errores['direccion'] = 'Introduce una dirección completa.';
    }

    if (empty($errores)) {
        try {
            /* UPDATE: modificamos solo este cliente (WHERE id = :id).
               Sin WHERE, actualizaríamos TODOS los clientes — error crítico. */
            $stmt = $pdo->prepare(
                "UPDATE clientes
                 SET nombre    = :nombre,
                     empresa   = :empresa,
                     email     = :email,
                     telefono  = :telefono,
                     direccion = :direccion,
                     notas     = :notas
                 WHERE id = :id"
            );

            $stmt->execute([
                ':nombre'    => $datos['nombre'],
                ':empresa'   => $datos['empresa']   ?: null,
                ':email'     => $datos['email'],
                ':telefono'  => $datos['telefono'],
                ':direccion' => $datos['direccion'],
                ':notas'     => $datos['notas']     ?: null,
                ':id'        => $id,
            ]);

            /* rowCount() devuelve el número de filas afectadas por el UPDATE.
               Si es 0, puede significar que los datos no cambiaron (no es un error). */
            $_SESSION['msg'] = '✓ Cliente "' . $datos['nombre'] . '" actualizado correctamente.';
            header('Location: listar.php');
            exit;

        } catch (PDOException $e) {
            if ($e->getCode() === '23000') {
                $errores['email'] = 'Este email ya está registrado por otro cliente.';
            } else {
                error_log('CubiertasChueca Admin/editar.php UPDATE: ' . $e->getMessage());
                $errores['general'] = 'Error al guardar los cambios.';
            }
        }
    }
}
?>

<!-- ============================================================
     FORMULARIO DE EDICIÓN (igual que crear.php pero pre-rellenado)
     ============================================================ -->
<main class="panel-main">

  <header class="panel-header">
    <h1>Editar cliente — <?= htmlspecialchars($clienteActual['nombre']) ?></h1>
    <a href="listar.php" class="btn-secondary">← Volver a la lista</a>
  </header>

  <?php if (!empty($errores['general'])): ?>
    <p class="alerta alerta-error" role="alert">
      <?= htmlspecialchars($errores['general']) ?>
    </p>
  <?php endif; ?>

  <form method="POST" action="" class="form-crud" novalidate>

    <p class="form-group">
      <label for="nombre">Nombre completo *</label>
      <input type="text" id="nombre" name="nombre"
             value="<?= htmlspecialchars($datos['nombre'] ?? '') ?>"
             maxlength="60" required
             class="<?= !empty($errores['nombre']) ? 'error' : '' ?>">
      <?php if (!empty($errores['nombre'])): ?>
        <span class="msg-error visible"><?= htmlspecialchars($errores['nombre']) ?></span>
      <?php endif; ?>
    </p>

    <p class="form-group">
      <label for="empresa">Empresa (opcional)</label>
      <input type="text" id="empresa" name="empresa"
             value="<?= htmlspecialchars($datos['empresa'] ?? '') ?>"
             maxlength="80">
    </p>

    <p class="form-group">
      <label for="email">Correo electrónico *</label>
      <input type="email" id="email" name="email"
             value="<?= htmlspecialchars($datos['email'] ?? '') ?>"
             maxlength="100" required
             class="<?= !empty($errores['email']) ? 'error' : '' ?>">
      <?php if (!empty($errores['email'])): ?>
        <span class="msg-error visible"><?= htmlspecialchars($errores['email']) ?></span>
      <?php endif; ?>
    </p>

    <p class="form-group">
      <label for="telefono">Teléfono * (9 dígitos)</label>
      <input type="tel" id="telefono" name="telefono"
             value="<?= htmlspecialchars($datos['telefono'] ?? '') ?>"
             maxlength="9" required
             class="<?= !empty($errores['telefono']) ? 'error' : '' ?>">
      <?php if (!empty($errores['telefono'])): ?>
        <span class="msg-error visible"><?= htmlspecialchars($errores['telefono']) ?></span>
      <?php endif; ?>
    </p>

    <p class="form-group">
      <label for="direccion">Dirección de la obra *</label>
      <input type="text" id="direccion" name="direccion"
             value="<?= htmlspecialchars($datos['direccion'] ?? '') ?>"
             required
             class="<?= !empty($errores['direccion']) ? 'error' : '' ?>">
      <?php if (!empty($errores['direccion'])): ?>
        <span class="msg-error visible"><?= htmlspecialchars($errores['direccion']) ?></span>
      <?php endif; ?>
    </p>

    <p class="form-group">
      <label for="notas">Notas internas (opcional)</label>
      <textarea id="notas" name="notas" rows="3">
        <?= htmlspecialchars($datos['notas'] ?? '') ?>
      </textarea>
    </p>

    <p class="botones-form">
      <button type="submit" class="btn-primary">Guardar cambios</button>
      <a href="listar.php" class="btn-secondary">Cancelar</a>
    </p>

  </form>

</main>

<?php require_once '../includes/footer.php'; ?>
