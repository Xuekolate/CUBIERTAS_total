<?php
/* ============================================================
   clientes/crear.php — CubiertasChueca Admin
   ============================================================
   CREATE — Muestra el formulario (GET) y procesa el INSERT (POST).

   PATRÓN POST/REDIRECT/GET (PRG):
     - GET  → mostramos el formulario vacío
     - POST → procesamos los datos:
               - Si hay errores: mostramos el formulario CON los
                 errores y los valores introducidos (para no perderlos)
               - Si todo OK: INSERT en BD + redirect a listar.php

   Por qué es importante el redirect:
     Sin redirect, si el usuario pulsa F5 después de crear,
     el navegador pregunta "¿Reenviar formulario?" y se inserta
     un cliente duplicado. Con redirect, F5 recarga la lista (GET).
   ============================================================ */

$tituloPagina = 'Nuevo cliente';
require_once '../config/db.php';
require_once '../includes/header.php';

/* Inicializamos variables que usaremos en ambos casos (GET y POST) */
$errores = [];  // Array de errores de validación: ['nombre' => 'mensaje', ...]
$datos   = [];  // Datos del formulario, para repoblar los campos si hay error

/* ============================================================
   PROCESAMIENTO DEL FORMULARIO (solo en POST)
   ============================================================
   $_SERVER['REQUEST_METHOD'] nos dice si la petición es GET o POST.
   Cuando el usuario visita la página por primera vez → GET
   Cuando el usuario envía el formulario → POST */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    /* ---- 1. RECOGER Y SANEAR LOS DATOS ---- */
    /* $_POST contiene los valores enviados por el formulario.
       trim() elimina espacios al inicio y al final del texto.
       El operador ?? '' evita el error si el campo no existe en $_POST. */
    $datos['nombre']    = trim($_POST['nombre']    ?? '');
    $datos['empresa']   = trim($_POST['empresa']   ?? '');
    $datos['email']     = trim($_POST['email']     ?? '');
    $datos['telefono']  = trim($_POST['telefono']  ?? '');
    $datos['direccion'] = trim($_POST['direccion'] ?? '');
    $datos['notas']     = trim($_POST['notas']     ?? '');

    /* ---- 2. VALIDAR EN PHP ---- */
    /* IMPORTANTE: aunque ya validemos con JavaScript en el navegador,
       SIEMPRE hay que validar también en el servidor.
       ¿Por qué? Porque el usuario puede:
         - Desactivar JavaScript
         - Usar Postman o curl para enviar datos directamente
         - Modificar el HTML con las DevTools antes de enviar */

    if (strlen($datos['nombre']) < 2) {
        $errores['nombre'] = 'El nombre debe tener al menos 2 caracteres.';
    } elseif (strlen($datos['nombre']) > 60) {
        $errores['nombre'] = 'El nombre no puede superar 60 caracteres.';
    }

    /* filter_var con FILTER_VALIDATE_EMAIL valida el formato del email
       de forma más robusta que cualquier regex manual. */
    if (!filter_var($datos['email'], FILTER_VALIDATE_EMAIL)) {
        $errores['email'] = 'Introduce un correo electrónico válido.';
    }

    /* preg_match comprueba si el valor coincide con la expresión regular.
       ^ = inicio, [0-9] = dígito, {9} = exactamente 9 veces, $ = fin */
    if (!preg_match('/^[0-9]{9}$/', $datos['telefono'])) {
        $errores['telefono'] = 'El teléfono debe tener exactamente 9 dígitos.';
    }

    if (strlen($datos['direccion']) < 5) {
        $errores['direccion'] = 'Introduce una dirección completa.';
    }

    /* ---- 3. SI NO HAY ERRORES → INSERTAR EN LA BD ---- */
    if (empty($errores)) {
        try {
            $pdo = conectarBD();

            /* PREPARED STATEMENT con parámetros NOMBRADOS (:nombre).
               Más legible que los posicionales (?) cuando hay muchos parámetros.
               Ventaja: el orden de los valores en execute() no importa
               siempre que los nombres coincidan con los placeholders. */
            $stmt = $pdo->prepare(
                "INSERT INTO clientes (nombre, empresa, email, telefono, direccion, notas)
                 VALUES (:nombre, :empresa, :email, :telefono, :direccion, :notas)"
            );

            $stmt->execute([
                ':nombre'    => $datos['nombre'],
                ':empresa'   => $datos['empresa']   ?: null,
                /* ?: null convierte cadena vacía en NULL para la BD.
                   En MySQL es mejor guardar NULL que '' para campos opcionales.
                   Así podemos distinguir "no informado" de "informado vacío". */
                ':email'     => $datos['email'],
                ':telefono'  => $datos['telefono'],
                ':direccion' => $datos['direccion'],
                ':notas'     => $datos['notas']     ?: null,
            ]);

            /* ---- 4. REDIRECT (patrón PRG) ---- */
            /* Guardamos el mensaje de éxito en sesión.
               Después del redirect, header.php lo mostrará y lo borrará. */
            $_SESSION['msg'] = '✓ Cliente "' . $datos['nombre'] . '" creado correctamente.';

            /* header('Location: url') le dice al navegador que vaya a esa URL.
               exit; es OBLIGATORIO después del header redirect.
               Sin exit, PHP seguiría ejecutando el resto del código. */
            header('Location: listar.php');
            exit;

        } catch (PDOException $e) {
            /* Detectamos si el error es de email duplicado.
               El código SQLSTATE '23000' es "Integrity constraint violation".
               Ocurre cuando intentamos insertar un email que ya existe (UNIQUE KEY). */
            if ($e->getCode() === '23000') {
                $errores['email'] = 'Este email ya está registrado en el sistema.';
            } else {
                /* Error desconocido: lo logueamos y mostramos mensaje genérico */
                error_log('CubiertasChueca Admin/crear.php: ' . $e->getMessage());
                $errores['general'] = 'Error al guardar. Inténtalo de nuevo más tarde.';
            }
        }
    }
    /* Si hay errores, el código continúa y muestra el formulario
       con $errores y $datos para que el usuario vea qué falló
       y no tenga que volver a escribir todo. */
}
?>

<!-- ============================================================
     FORMULARIO DE CREACIÓN
     ============================================================ -->
<main class="panel-main">

  <header class="panel-header">
    <h1>Nuevo cliente</h1>
    <a href="listar.php" class="btn-secondary">← Volver a la lista</a>
  </header>

  <!-- Error general de BD -->
  <?php if (!empty($errores['general'])): ?>
    <p class="alerta alerta-error" role="alert">
      <?= htmlspecialchars($errores['general']) ?>
    </p>
  <?php endif; ?>

  <!--
    novalidate: desactivamos la validación HTML5 nativa del navegador
    para que los errores los gestione PHP (en el servidor) de forma uniforme.
    En un proyecto real combinaríamos validación JS + PHP.
    method="POST": los datos van en el cuerpo de la petición, no en la URL.
    action="": envía al mismo script (crear.php procesa el GET y el POST).
  -->
  <form method="POST" action="" class="form-crud" novalidate>

    <!-- ---- NOMBRE ---- -->
    <p class="form-group">
      <label for="nombre">Nombre completo *</label>
      <input
        type="text"
        id="nombre"
        name="nombre"
        value="<?= htmlspecialchars($datos['nombre'] ?? '') ?>"
        maxlength="60"
        required
        autocomplete="name"
        class="<?= !empty($errores['nombre']) ? 'error' : '' ?>"
      >
      <!--
        value="..." repuebla el campo si el formulario se vuelve a mostrar por error.
        htmlspecialchars() protege contra XSS en el atributo value.
        La clase 'error' añade el borde rojo si hay error en este campo.
      -->
      <?php if (!empty($errores['nombre'])): ?>
        <span class="msg-error visible" role="alert">
          <?= htmlspecialchars($errores['nombre']) ?>
        </span>
      <?php endif; ?>
    </p>

    <!-- ---- EMPRESA (opcional) ---- -->
    <p class="form-group">
      <label for="empresa">Empresa (opcional)</label>
      <input
        type="text"
        id="empresa"
        name="empresa"
        value="<?= htmlspecialchars($datos['empresa'] ?? '') ?>"
        maxlength="80"
        autocomplete="organization"
      >
    </p>

    <!-- ---- EMAIL ---- -->
    <p class="form-group">
      <label for="email">Correo electrónico *</label>
      <input
        type="email"
        id="email"
        name="email"
        value="<?= htmlspecialchars($datos['email'] ?? '') ?>"
        maxlength="100"
        required
        autocomplete="email"
        class="<?= !empty($errores['email']) ? 'error' : '' ?>"
      >
      <?php if (!empty($errores['email'])): ?>
        <span class="msg-error visible" role="alert">
          <?= htmlspecialchars($errores['email']) ?>
        </span>
      <?php endif; ?>
    </p>

    <!-- ---- TELÉFONO ---- -->
    <p class="form-group">
      <label for="telefono">Teléfono * (9 dígitos)</label>
      <input
        type="tel"
        id="telefono"
        name="telefono"
        value="<?= htmlspecialchars($datos['telefono'] ?? '') ?>"
        maxlength="9"
        required
        autocomplete="tel"
        class="<?= !empty($errores['telefono']) ? 'error' : '' ?>"
      >
      <?php if (!empty($errores['telefono'])): ?>
        <span class="msg-error visible" role="alert">
          <?= htmlspecialchars($errores['telefono']) ?>
        </span>
      <?php endif; ?>
    </p>

    <!-- ---- DIRECCIÓN ---- -->
    <p class="form-group">
      <label for="direccion">Dirección de la obra *</label>
      <input
        type="text"
        id="direccion"
        name="direccion"
        value="<?= htmlspecialchars($datos['direccion'] ?? '') ?>"
        required
        autocomplete="street-address"
        class="<?= !empty($errores['direccion']) ? 'error' : '' ?>"
      >
      <?php if (!empty($errores['direccion'])): ?>
        <span class="msg-error visible" role="alert">
          <?= htmlspecialchars($errores['direccion']) ?>
        </span>
      <?php endif; ?>
    </p>

    <!-- ---- NOTAS ---- -->
    <p class="form-group">
      <label for="notas">Notas internas (opcional)</label>
      <textarea
        id="notas"
        name="notas"
        rows="3"
        placeholder="Información adicional: acceso, persona de contacto, etc."
      ><?= htmlspecialchars($datos['notas'] ?? '') ?></textarea>
      <!--
        En <textarea> el value va entre las etiquetas, no en un atributo.
        htmlspecialchars() aquí también protege contra XSS.
      -->
    </p>

    <!-- ---- BOTONES ---- -->
    <p class="botones-form">
      <button type="submit" class="btn-primary">Guardar cliente</button>
      <a href="listar.php" class="btn-secondary">Cancelar</a>
    </p>

  </form>

</main>

<?php require_once '../includes/footer.php'; ?>
