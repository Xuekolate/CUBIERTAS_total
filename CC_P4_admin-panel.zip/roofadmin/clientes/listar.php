<?php
/* ============================================================
   clientes/listar.php — CubiertasChueca Admin
   ============================================================
   READ — Lista todos los clientes con búsqueda y paginación básica.

   PATRÓN MVC (simplificado sin framework):
     - Este archivo actúa como CONTROLLER + VIEW combinados.
     - Lo ideal sería separarlo, pero para un proyecto de portfolio
       sin framework es aceptable y más fácil de entender.

   FLUJO DE LA PÁGINA:
     1. Cargamos config/db.php (función conectarBD)
     2. Cargamos includes/header.php (HTML + menú)
     3. Conectamos a la BD
     4. Ejecutamos la query (con o sin búsqueda)
     5. Imprimimos la tabla de resultados
     6. Cargamos includes/footer.php (cierre del HTML)
   ============================================================ */

/* Definimos el título antes del header para que lo use en el <title> */
$tituloPagina = 'Clientes';

/* require_once incluye el archivo UNA SOLA VEZ.
   Si se llama dos veces, la segunda se ignora.
   require (sin _once) daría error si se llama dos veces. */
require_once '../config/db.php';
require_once '../includes/header.php';

/* ============================================================
   BÚSQUEDA OPCIONAL
   ============================================================
   $_GET es el array superglobal que contiene los parámetros
   de la URL. Si la URL es "listar.php?q=antonio", entonces
   $_GET['q'] es 'antonio'.

   El operador ?? devuelve '' si $_GET['q'] no existe.
   trim() elimina espacios al principio y al final. */
$busqueda = trim($_GET['q'] ?? '');

/* ============================================================
   CONSULTA A LA BASE DE DATOS
   ============================================================ */
$clientes = [];
$error    = '';

try {
    /* Creamos la conexión PDO */
    $pdo = conectarBD();

    if ($busqueda !== '') {
        /* ---- Búsqueda activa ---- */

        /* PREPARED STATEMENT con parámetros posicionales (?):
           Nunca concatenes variables directamente en el SQL:
             "WHERE nombre = '$busqueda'"  ← VULNERABLE a SQL Injection
             "WHERE nombre LIKE ?"         ← SEGURO (el valor va aparte)

           El flujo de un prepared statement:
             1. prepare(): enviamos el SQL con placeholders (?)
             2. execute(): enviamos los valores (PDO los escapa automáticamente)
             3. fetch() / fetchAll(): recogemos los resultados */
        $stmt = $pdo->prepare(
            "SELECT id, nombre, empresa, email, telefono, creado_en
             FROM clientes
             WHERE nombre LIKE ?
                OR empresa LIKE ?
                OR email LIKE ?
             ORDER BY creado_en DESC"
        );

        /* LIKE con % busca el texto en cualquier posición:
           '%antonio%' encuentra 'Antonio García', 'San Antonio', etc.
           Pasamos el mismo parámetro tres veces (una por cada ?) */
        $patron = '%' . $busqueda . '%';
        $stmt->execute([$patron, $patron, $patron]);

    } else {
        /* ---- Sin búsqueda: todos los clientes ---- */

        /* query() se usa cuando no hay parámetros variables.
           Es equivalente a prepare() + execute() sin parámetros. */
        $stmt = $pdo->query(
            "SELECT id, nombre, empresa, email, telefono, creado_en
             FROM clientes
             ORDER BY creado_en DESC"
        );
    }

    /* fetchAll() devuelve TODAS las filas como un array de arrays asociativos.
       Gracias a PDO::FETCH_ASSOC que configuramos en db.php,
       cada fila es ['id' => 1, 'nombre' => 'Antonio', ...] */
    $clientes = $stmt->fetchAll();

} catch (PDOException $e) {
    /* Si la conexión falla o hay un error de SQL, capturamos la excepción.
       En PRODUCCIÓN: loguear el error real, mostrar mensaje genérico.
       En DESARROLLO: puedes hacer echo $e->getMessage() para ver el error.

       error_log() escribe en el log de errores de Apache/PHP
       (en XAMPP está en: xampp/apache/logs/error.log) */
    error_log('CubiertasChueca Admin/clientes/listar.php: ' . $e->getMessage());
    $error = 'Error al conectar con la base de datos. Inténtalo de nuevo.';
}
?>

<!-- ============================================================
     CONTENIDO PRINCIPAL DE LA PÁGINA
     ============================================================ -->
<main class="panel-main">

  <!-- Cabecera de sección: título + botón de crear -->
  <header class="panel-header">
    <h1>Clientes</h1>
    <a href="crear.php" class="btn-primary">+ Nuevo cliente</a>
  </header>

  <!-- Mensaje de error de BD (si lo hay) -->
  <?php if ($error): ?>
    <p class="alerta alerta-error" role="alert">
      <?= htmlspecialchars($error) ?>
    </p>
  <?php endif; ?>

  <!-- ============================================================
       FORMULARIO DE BÚSQUEDA
       method="GET": los parámetros van en la URL (?q=texto).
       Esto permite compartir la URL de búsqueda y que el botón
       atrás funcione correctamente.
       ============================================================ -->
  <form class="buscador" method="GET" action="" role="search">
    <label for="buscar-cli" class="sr-only">Buscar cliente</label>
    <input
      type="search"
      id="buscar-cli"
      name="q"
      value="<?= htmlspecialchars($busqueda) ?>"
      placeholder="Buscar por nombre, empresa o email..."
      autocomplete="off"
    >
    <button type="submit" class="btn-buscar">Buscar</button>
    <?php if ($busqueda): ?>
      <!-- Solo mostramos "Limpiar" si hay una búsqueda activa -->
      <a href="listar.php" class="btn-limpiar">✕ Limpiar</a>
    <?php endif; ?>
  </form>

  <!-- ============================================================
       TABLA DE RESULTADOS
       ============================================================ -->
  <?php if ($error): ?>
    <!-- Error ya mostrado arriba, no mostramos la tabla -->

  <?php elseif (empty($clientes)): ?>
    <!-- Sin resultados -->
    <p class="aviso">
      <?= $busqueda
          ? 'No se encontraron clientes para "' . htmlspecialchars($busqueda) . '".'
          : 'Todavía no hay clientes. <a href="crear.php">Crea el primero</a>.' ?>
    </p>

  <?php else: ?>
    <!-- Tabla de clientes -->
    <table class="tabla-datos">
      <caption class="sr-only">
        Lista de clientes<?= $busqueda ? ' — búsqueda: ' . htmlspecialchars($busqueda) : '' ?>
      </caption>
      <thead>
        <tr>
          <th scope="col">ID</th>
          <th scope="col">Nombre</th>
          <th scope="col" class="col-empresa">Empresa</th>
          <th scope="col">Email</th>
          <th scope="col" class="col-tel">Teléfono</th>
          <th scope="col" class="col-fecha">Registrado</th>
          <th scope="col">Acciones</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($clientes as $cli): ?>
          <!--
            foreach recorre el array $clientes.
            En cada iteración, $cli es un array asociativo con los
            datos de un cliente: $cli['id'], $cli['nombre'], etc.
          -->
          <tr>
            <td><?= $cli['id'] ?></td>

            <td>
              <!-- El nombre es un enlace a la página de edición -->
              <a href="editar.php?id=<?= $cli['id'] ?>" class="link-tabla">
                <?= htmlspecialchars($cli['nombre']) ?>
              </a>
            </td>

            <td class="col-empresa">
              <?= htmlspecialchars($cli['empresa'] ?? '—') ?>
              <!-- ?? '—' muestra un guión si empresa es NULL -->
            </td>

            <td>
              <a href="mailto:<?= htmlspecialchars($cli['email']) ?>">
                <?= htmlspecialchars($cli['email']) ?>
              </a>
            </td>

            <td class="col-tel">
              <?= htmlspecialchars($cli['telefono']) ?>
            </td>

            <td class="col-fecha">
              <?php
              /* date() formatea una fecha.
                 strtotime() convierte el string de MySQL ('2024-04-01 14:30:00')
                 a un timestamp Unix (número de segundos desde 1/1/1970).
                 Resultado: "01/04/2024" */
              echo date('d/m/Y', strtotime($cli['creado_en']));
              ?>
            </td>

            <td class="acciones">
              <!-- Botón editar -->
              <a href="editar.php?id=<?= $cli['id'] ?>"
                 class="btn-edit"
                 title="Editar cliente">
                ✏️ Editar
              </a>

              <!-- Botón eliminar con confirmación JavaScript -->
              <a href="eliminar.php?id=<?= $cli['id'] ?>"
                 class="btn-delete"
                 title="Eliminar cliente"
                 onclick="return confirm('¿Eliminar al cliente <?= htmlspecialchars($cli['nombre'], ENT_QUOTES) ?>?\nEsta acción no se puede deshacer.')">
                 <!--
                   ENT_QUOTES escapa también las comillas simples,
                   necesario porque estamos dentro de un atributo onclick con comillas simples.
                   \n en el confirm() crea un salto de línea en el diálogo.
                 -->
                🗑️ Eliminar
              </a>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>

    <!-- Contador de resultados -->
    <p class="total-resultados">
      <?php
      $n = count($clientes);
      if ($busqueda) {
          echo $n . ' cliente' . ($n !== 1 ? 's' : '') .
               ' encontrado' . ($n !== 1 ? 's' : '') .
               ' para "' . htmlspecialchars($busqueda) . '"';
      } else {
          echo $n . ' cliente' . ($n !== 1 ? 's' : '') . ' en total';
      }
      ?>
    </p>

  <?php endif; ?>

</main>

<?php require_once '../includes/footer.php'; ?>
