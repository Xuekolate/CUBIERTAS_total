<?php
/* ============================================================
   clientes/eliminar.php — CubiertasChueca Admin
   ============================================================
   DELETE — Elimina un cliente de la base de datos.

   IMPORTANTE sobre eliminar datos:
     - Solo aceptamos peticiones GET con confirmación previa en JS
       (el onclick="return confirm(...)" en listar.php)
     - Comprobamos que el cliente existe antes de borrar
     - Si el cliente tiene presupuestos asociados, MySQL lanzará
       un error de FK (ON DELETE RESTRICT) — lo capturamos
     - Después del DELETE → redirect a listar.php (patrón PRG)

   En una aplicación más compleja usaríamos POST para el DELETE
   (más seguro, evita borrar accidentalmente al compartir una URL).
   Para este portfolio con confirmación JS es suficiente.
   ============================================================ */

require_once '../config/db.php';

/* Iniciamos sesión para poder usar $_SESSION['msg'] */
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/* ============================================================
   VALIDAR EL ID
   ============================================================ */
$id = intval($_GET['id'] ?? 0);

if ($id <= 0) {
    $_SESSION['error'] = 'ID de cliente no válido.';
    header('Location: listar.php');
    exit;
}

/* ============================================================
   EJECUTAR EL DELETE
   ============================================================ */
try {
    $pdo = conectarBD();

    /* Primero comprobamos que el cliente existe y guardamos su nombre
       para el mensaje de confirmación. */
    $stmtCheck = $pdo->prepare("SELECT nombre FROM clientes WHERE id = :id LIMIT 1");
    $stmtCheck->execute([':id' => $id]);
    $cliente = $stmtCheck->fetch();

    if (!$cliente) {
        $_SESSION['error'] = 'No se encontró el cliente con ID ' . $id . '.';
        header('Location: listar.php');
        exit;
    }

    /* Ejecutamos el DELETE */
    $stmtDelete = $pdo->prepare("DELETE FROM clientes WHERE id = :id");
    $stmtDelete->execute([':id' => $id]);

    $_SESSION['msg'] = '✓ Cliente "' . $cliente['nombre'] . '" eliminado correctamente.';

} catch (PDOException $e) {
    /* Si el cliente tiene presupuestos o incidencias vinculadas,
       MySQL lanza un error de integridad referencial (código 23000).
       ON DELETE RESTRICT en el SQL lo impide para proteger los datos. */
    if ($e->getCode() === '23000') {
        $_SESSION['error'] = 'No se puede eliminar al cliente "' . $cliente['nombre'] .
                             '" porque tiene presupuestos o incidencias asociadas. ' .
                             'Elimínalos primero.';
    } else {
        error_log('CubiertasChueca Admin/eliminar.php: ' . $e->getMessage());
        $_SESSION['error'] = 'Error al eliminar el cliente. Inténtalo de nuevo.';
    }
}

/* Siempre redirigimos a la lista, tanto si tuvo éxito como si hubo error */
header('Location: listar.php');
exit;
