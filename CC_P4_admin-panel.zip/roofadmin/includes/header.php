<?php
/* ============================================================
   includes/header.php — CubiertasChueca Admin
   ============================================================
   Cabecera HTML compartida por todas las páginas del panel
   de gestión de CubiertasChueca.
   ============================================================ */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$carpetaActual = basename(dirname($_SERVER['PHP_SELF']));
$titulo = ($tituloPagina ?? 'Panel') . ' | CubiertasChueca Admin';
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= htmlspecialchars($titulo) ?></title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Work+Sans:wght@300;400;600&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="<?= str_repeat('../', substr_count($_SERVER['PHP_SELF'], '/') - 2) ?>css/style.css">
</head>
<body>

<header class="panel-header-global">
  <a href="/cubiertaschueca-admin/index.php" class="brand">🏠 CubiertasChueca</a>
  <nav class="nav-principal" aria-label="Navegación del panel de CubiertasChueca">
    <a href="/cubiertaschueca-admin/clientes/listar.php"
       class="<?= $carpetaActual === 'clientes'     ? 'activo' : '' ?>">Clientes</a>
    <a href="/cubiertaschueca-admin/presupuestos/listar.php"
       class="<?= $carpetaActual === 'presupuestos' ? 'activo' : '' ?>">Presupuestos</a>
    <a href="/cubiertaschueca-admin/incidencias/listar.php"
       class="<?= $carpetaActual === 'incidencias'  ? 'activo' : '' ?>">Incidencias</a>
  </nav>
</header>

<?php if (!empty($_SESSION['msg'])): ?>
  <p class="flash-msg flash-ok" role="alert"><?= htmlspecialchars($_SESSION['msg']) ?></p>
  <?php unset($_SESSION['msg']); ?>
<?php endif; ?>

<?php if (!empty($_SESSION['error'])): ?>
  <p class="flash-msg flash-error" role="alert"><?= htmlspecialchars($_SESSION['error']) ?></p>
  <?php unset($_SESSION['error']); ?>
<?php endif; ?>
