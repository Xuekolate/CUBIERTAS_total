<?php
/* ============================================================
   includes/footer.php — CubiertasChueca Admin
   Pie de página compartido por todas las páginas del panel.
   ============================================================ */
?>
<footer class="panel-footer">
  <p>
    &copy; <?= date('Y') ?> CubiertasChueca &mdash;
    Panel de gestión interno &mdash; C/ Sorbesopas N&ordm; 20, Alcorcón, Madrid
  </p>
</footer>

</body>
</html>
